﻿/**
 * Licensed under the MIT License
 * 
 * Copyright (c) 2009 alumican.net (www.alumican.net) and 
 *               Spark project (www.libspark.org)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package 
{
	import flash.display.BitmapData;
	import flash.events.MouseEvent;
	import flash.geom.Matrix;
	import flash.geom.Rectangle;
	import org.libspark.thread.Thread;
	
	import net.alumican.as3.alfluid.Melt;
	
	/**
	 * MainThread
	 *
	 * @author alumican.net<Yukiya Okuda>
	 */
	
	public class MainThread extends Thread
	{
		
		//-------------------------------------
		// CLASS CONSTANTS
		//-------------------------------------
		
		
		
		
		
		//-------------------------------------
		// VARIABLES
		//-------------------------------------
		
		private var _root:FunnyFaceGenerator;
		private var _melt:Melt;
		private var _source:BitmapData;
		private var _uploader:UploadImageThread;
		private var _downloader:DownloadImageThread;
		
		
		
		
		
		//-------------------------------------
		// STAGE INSTANCES
		//-------------------------------------
		
		
		
		
		
		//-------------------------------------
		// GETTER/SETTER
		//-------------------------------------
		
		
		
		
		
		//-------------------------------------
		// CONSTRUCTOR
		//-------------------------------------
		
		/**
		 * Constructor
		 * @param	root
		 */
		public function MainThread(root:FunnyFaceGenerator):void 
		{
			_root = root;
			
			//init source
			_source = new BitmapData(_root.target.width, _root.target.height, false);
			_source.draw(_root.target);
			
			//create instance
			_melt = new Melt(_source, false, 10, _root.target.width, _root.target.height);
			
			//config
			_melt.fluidMagnitude = 50.0;  //default 150
			_melt.fluidFlowSize  = 1.5;   //default 2
		//	_melt.fluidUseDecay = false;  //default true
		//	_melt.fluidUseMouse = false;  //default true
		//	_melt.fluidCanvasTone = new ColorMatrixFilter();
			
			//set mouse event
			_melt.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void
			{
				_melt.fluidUseDecay = !_melt.fluidUseDecay;
			});
			
			_melt.x = _root.target.x;
			_melt.y = _root.target.y;
			
			_root.addChild(_melt);
			
			_root.uploadButton.buttonMode   = true;
			_root.downloadButton.buttonMode = true;
		}
		
		
		
		
		
		//-------------------------------------
		// METHODS
		//-------------------------------------
		
		/**
		 * execute function of thread
		 */
		override protected function run():void 
		{
			_event();
		}
		
		/**
		 * set events
		 */
		private function _event():void
		{
			event(_root.uploadButton, MouseEvent.CLICK, _upload);
			event(_root.downloadButton, MouseEvent.CLICK, _download);
		}
		
		/**
		 * upload your photo
		 * @param	e
		 */
		private function _upload(e:MouseEvent):void
		{
			_uploader = new UploadImageThread();
			_uploader.start();
			_uploader.join();
			
			next(_uploaded);
			
			_event();
		}
		
		/**
		 * upload complete handler
		 * @param	e
		 */
		private function _uploaded():void
		{
			var bmd:BitmapData = _uploader.content.bitmapData;
			var ratioW:Number  = _root.target.width  / bmd.width;
			var ratioH:Number  = _root.target.height / bmd.height;
			var ratio:Number   = (ratioW > ratioH) ? ratioW : ratioH;
			_source.draw(bmd, new Matrix(ratio, 0, 0, ratio));
			
			_event();
		}
		
		/**
		 * download fluid picture
		 * @param	e
		 */
		private function _download(e:MouseEvent):void
		{
			_melt.fluidUseDecay = false;
			
			var w:uint = _root.target.width  + 60;
			var h:uint = _root.target.height + 60;
			
			var data:BitmapData = new BitmapData(w, h, false);
			data.draw(_root, new Matrix(1, 0, 0, 1, -_root.frame.x, -_root.frame.y), null, null, new Rectangle(0, 0, w, h));
			
			_downloader = new DownloadImageThread(data);
			_downloader.start();
			_downloader.join();
			
			_event();
		}
		
		
		
		
		//-------------------------------------
		// EVENT HANDLER
		//-------------------------------------
	}
}