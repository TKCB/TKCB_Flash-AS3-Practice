package
{
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.filters.GlowFilter;
	
	/**
	 * 刀光代码效率优化版
	 * @author j
	 */
	[SWF(width="550",height="400",frameRate="24",backgroundColor="#000000")]
	public class CutFruit extends Sprite
	{
		private var sets:Vector.<CutFruitLine> = new Vector.<CutFruitLine>;
		
		private var cacheX:int;
		private var cacheY:int;
		private var isDown:Boolean;
		private var linesize:Number;
		private var color:uint;
		
		public function CutFruit($linesize:Number = 8, $lineColor:uint = 0xFFFFFF, $filters:Array = null)
		{
			linesize = $linesize;
			color = $lineColor;
			
			if ($filters == null)
			{
				this.filters = [new GlowFilter(0x00FF95, 1, 10, 10, 2, 1, false, false)];
			}
			else
			{
				this.filters = $filters;
			}
			
			this.mouseEnabled = false;
			this.mouseChildren = false;
			
			this.addEventListener(Event.ADDED_TO_STAGE, start);
		}
		
		private function start(e:Event):void
		{
			stage.addEventListener(MouseEvent.MOUSE_DOWN, downHandler);
			stage.addEventListener(MouseEvent.MOUSE_UP, upHandler);
			
			this.removeEventListener(Event.ADDED_TO_STAGE, start);
			this.addEventListener(Event.REMOVED_FROM_STAGE, stop);
		}
		
		private function stop(e:Event):void
		{
			stage.removeEventListener(MouseEvent.MOUSE_DOWN, downHandler);
			stage.removeEventListener(MouseEvent.MOUSE_UP, upHandler);
			isDown = false;
			
			this.addEventListener(Event.ADDED_TO_STAGE, start);
			this.removeEventListener(Event.REMOVED_FROM_STAGE, stop);
			
			this.removeEventListener(Event.ENTER_FRAME, enterFrame);
			sets.length = 0;
		}
		
		private function downHandler(e:MouseEvent):void
		{
			cacheX = stage.mouseX;
			cacheY = stage.mouseY;
			isDown = true;
			this.addEventListener(Event.ENTER_FRAME, enterFrame);
		}
		
		private function upHandler(e:MouseEvent):void
		{
			isDown = false;
		
		}
		
		private function enterFrame(e:Event):void
		{
			if (isDown == true)
			{
				if (cacheX != stage.mouseX || cacheY != stage.mouseY)
				{
					sets[sets.length] = new CutFruitLine(cacheX, cacheY, stage.mouseX, stage.mouseY, linesize);
					cacheX = stage.mouseX;
					cacheY = stage.mouseY;
				}
			}
			graphics.clear();
			var index:int = 0;
			var len:int = sets.length;
			var line:CutFruitLine;
			for (var i:int = 0; i < len; i++)
			{
				line = sets[index];
				if (line.linesize <= 0)
				{
					sets.splice(index, 1);
				}
				else
				{
					graphics.lineStyle(line.linesize, color);
					graphics.moveTo(line.sX, line.sY);
					graphics.lineTo(line.eX, line.eY);
					line.linesize -= 1;
					index++;
				}
			}
			if (isDown == false && sets.length == 0)
			{
				this.removeEventListener(Event.ENTER_FRAME, enterFrame);
			}
		}
	}
}