package
{
	
	public class CutFruitLine
	{
		public var sX:int;
		public var sY:int;
		public var eX:int;
		public var eY:int;
		public var linesize:Number;
		
		public function CutFruitLine($sX:int, $sY:int, $eX:int, $eY:int, $linesize:Number)
		{
			sX = $sX;
			sY = $sY;
			eX = $eX;
			eY = $eY;
			linesize = $linesize;
		}
	}
}