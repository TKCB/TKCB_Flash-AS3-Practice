package
{
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.events.MouseEvent;
	import flash.events.ProgressEvent;
	import flash.filters.GlowFilter;
	import flash.filters.GradientBevelFilter;
	import flash.geom.Point;
	import flash.geom.Rectangle;
	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.net.URLRequest;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	import flash.ui.Mouse;
	
	import game.Game;
	import game.Game_sound;
	import game.Line_Class;

	//这个一定要放在 最上面，在里面的话不对。
	[SWF(width=768,height=1366,backgroundColor=0x000000,frameRate=25)]
	
	public class Fruit_Game extends Sprite
	{
		[Embed(source='../lib/start1.jpg')]private var btn:Class;
		private var btnImg:BitmapData = (new btn as Bitmap).bitmapData;
		
		private var txt:TextField;
		
		private var _game:Game;
		/**
		 *  添加文字   和   开始显示的图片，点击舞台后，游戏开始。 
		 */		
		public function Fruit_Game()
		{
			//背景音乐
			Game_sound.getInstance().playSound(0);
			
			txt = new TextField();
			txt.multiline = true;
			//txt.autoSize = TextFieldAutoSize.CENTER;
			txt.width = 250;
			txt.x = 100;
			txt.y = 220;
			txt.textColor = 0xff0000;
			txt.mouseEnabled = false;
			var tfm:TextFormat = new TextFormat("宋体",20);
			txt.defaultTextFormat = tfm;
			//为了优化，减少  filters
			//txt.filters = [
				//new GradientBevelFilter(8, 90, [0xffd21e, 0xff0000], [1, 1], [0xff*0.25,0xff*0.75], 5, 5, 1, 1, "inner", true),
				//new GlowFilter(0xffffff, 1, 2, 2, 5),
				//new GlowFilter(0,1,2,2,10)];
			
			
			
			
			var btnBmd:Bitmap = new Bitmap(new BitmapData(stage.stageWidth,stage.stageHeight));	
			var rect:Rectangle = new Rectangle(0,0,768,1366);
			var pt:Point = new Point(0,0);
			var bmd:BitmapData = new BitmapData(768,1366,false,0xffffff);
			bmd.copyPixels(btnImg,rect,pt);
			btnBmd = new Bitmap(bmd);
			addChild(btnBmd);
			addChild(txt);
			stage.addEventListener(MouseEvent.CLICK,onClick,false,0,true);
			//clone返回一个新的 BitmapData 对象，它是对原始实例的克隆，
			//包含与原始实例所含位图完全相同的副本。
			//var map:BitmapData = btnBmd.bitmapData.clone();
			txt.text = "切水果游戏，点击开始！！！";//字一定要放在 舞台添加完txt的后面，不然，txt还没有字体样式和字体大小
			/*
			var random:int = Math.random()*3;
			_game = new Game(465,465,random);
			addChild(_game);
			*/
		}
		/**
		 * @param e 3种游戏背景   进入游戏
		 */		
		
		private function onClick(e:MouseEvent):void
		{
			Game_sound.getInstance().playSound(1);
			stage.removeEventListener(MouseEvent.CLICK,onClick);
			
			var random:int = Math.random()*3;
			_game = new Game(768,1366,random);
			addChild(_game);
		}

	}
}