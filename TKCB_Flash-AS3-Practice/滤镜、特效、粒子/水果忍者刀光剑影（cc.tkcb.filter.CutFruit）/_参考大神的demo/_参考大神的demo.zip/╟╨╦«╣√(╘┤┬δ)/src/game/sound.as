package client.sound
{
	import client.valueObject.SystemInfo;
	import client.valueObject.UserInfo;
	
	import flash.events.*;
	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.net.URLRequest;
	import flash.utils.Timer;
	
	public class GameSound
	{
		private static var _inst:GameSound;
		private var url:String = "music_sound/bird.mp3";
		private var song:SoundChannel;
		
		public var firstPlay:Boolean = true;
		
		private var soundFactory:Sound;
		
		private var stopSound:Sound;
		
		private var positionTimer:Timer;
		
		/**
		 * @private 背景音乐
		 */
		private var music:Sound;
		
		/**
		 * @private 砍树
		 */
		private var treeSound:Sound;
		
		/**
		 * @private 帮好友敲击建房
		 */
		private var buildSound:Sound;
		
		/**
		 * @private 爆出物品
		 */
		private var getThingSound:Sound;
		
		/**
		 * @private 打猎
		 */
		private var beastSound:Sound;
		
		/**
		 * @private 匪徒被打死
		 */
		private var ganDead:Sound;
		
		/**
		 * @private 关闭界面
		 */
		private var closeView:Sound;
		
		/**
		 * @private 猎犬打猎
		 */
		private var dogAttack:Sound;
		
		/**
		 * @private 移动后放置
		 */
		private var moveAdd:Sound;
		
		/**
		 * @private 匪徒帮忙
		 */
		private var ganHelp:Sound;
		
		/**
		 * @private 炸石头
		 */
		private var bbStone:Sound;
		
		/**
		 * @private 点击捡宝
		 */
		private var clickGetThing:Sound;
		
		/**
		 * @private 切换选项卡
		 */
		private var changeBtn:Sound;
		
		/**
		 * @private 打开一级界面
		 */
		private var openView:Sound;
		
		private var musicCh:SoundChannel;
		
		public function GameSound(single:SingletonEnforcer)
		{
			var request:URLRequest = new URLRequest(url);
			soundFactory = new Sound();
			soundFactory.addEventListener(Event.COMPLETE, completeHandler);
			soundFactory.addEventListener(Event.ID3, id3Handler);
			soundFactory.addEventListener(IOErrorEvent.IO_ERROR, ioErrorHandler);
			soundFactory.addEventListener(ProgressEvent.PROGRESS, progressHandler);
			soundFactory.load(request);
			
			music = new Sound();
			//music.addEventListener(Event.COMPLETE, completeMusic);
			music.load(new URLRequest("music_sound/music.mp3"));
			
			treeSound = new Sound();
			treeSound.load(new URLRequest("music_sound/cutDownTree.mp3"));
			
			buildSound = new Sound();
			buildSound.load(new URLRequest("music_sound/buildSound.mp3"));
			
			getThingSound = new Sound();
			getThingSound.load(new URLRequest("music_sound/getThingSound.mp3"));
			
			beastSound = new Sound();
			beastSound.load(new URLRequest("music_sound/beastSound.mp3"));
			
			ganDead = new Sound();
			ganDead.load(new URLRequest("music_sound/ganDead.mp3"));
			
			closeView = new Sound();
			closeView.load(new URLRequest("music_sound/closeView.mp3"));
			
			dogAttack = new Sound();
			dogAttack.load(new URLRequest("music_sound/dogAttack.mp3"));
			
			ganHelp = new Sound();
			ganHelp.load(new URLRequest("music_sound/ganHelp.mp3"));
			
			moveAdd = new Sound();
			moveAdd.load(new URLRequest("music_sound/moveAdd.mp3"));
			
			bbStone = new Sound();
			bbStone.load(new URLRequest("music_sound/bbStone.mp3"));
			
			clickGetThing = new Sound();
			clickGetThing.load(new URLRequest("music_sound/clickGetThing.mp3"));
			
			changeBtn = new Sound();
			changeBtn.load(new URLRequest("music_sound/changeBtn.mp3"));
			
			openView = new Sound();
			openView.load(new URLRequest("music_sound/openView.mp3"));
			
			stopSound = new Sound();
			//stopSound.addEventListener(Event.COMPLETE, completeMusic);
			stopSound.load(new URLRequest("music_sound/stop.mp3"));
		}
		public function completeMusic(evt:Event):void
		{
			//musicPlay();
			
		}
		public function musicPlay():void
		{
			//return;
			if(UserInfo.musicState == 0){
				//if(musicCh == null)
				musicCh = music.play(0,10000);
			}else{
				if(musicCh)musicCh.stop();
			}
		}
		/**
		 * 
		 * @param _soundType 0布谷鸟   1停止   2锯树   3打猎   4帮好友敲击建房  5爆出物品  6匪徒被打死
		 *   7关闭界面  8猎犬打猎   9移动后放置   10匪徒帮忙  11炸石头  12点击捡宝  13切换选项卡
		 */
		public function playSound(_soundType:int = 0):void
		{
			try{
				if(UserInfo.soundState == 0){
					switch(_soundType){
						case 0:
							song = soundFactory.play();
							break;
						case 1:
							song = stopSound.play();
							break;
						case 2:
							song = treeSound.play();
							break;
						case 3:
							song = beastSound.play();
							break;
						case 4:
							song = buildSound.play();
							break;
						case 5:
							song = getThingSound.play();
							break;
						case 6:
							song = ganDead.play();
							break;
						case 7:
							song = closeView.play();
							break;
						case 8:
							song = dogAttack.play();
							break;
						case 9:
							song = moveAdd.play();
							break;
						case 10:
							song = ganHelp.play();
							break;
						case 11:
							song = bbStone.play();
							break;
						case 12:
							song = clickGetThing.play();
							break;
						case 13:
							song = changeBtn.play();
							break;
						case 14:
							song = openView.play();
							break;
						
						
					}
				}
			}catch(e:Error){}
			//song.addEventListener(Event.SOUND_COMPLETE, soundCompleteHandler,false,0,true);
			/*
			positionTimer = new Timer(50);
			positionTimer.addEventListener(TimerEvent.TIMER, positionTimerHandler);
			positionTimer.start();
			*/
		}
		private function positionTimerHandler(event:TimerEvent):void {
			trace("positionTimerHandler: " + song.position.toFixed(2));
		}
		
		private function completeHandler(event:Event):void {
			trace("completeHandler: " + event);
		}
		
		private function id3Handler(event:Event):void {
			trace("id3Handler: " + event);
		}
		
		private function ioErrorHandler(event:Event):void {
			trace("ioErrorHandler: " + event);
		}
		
		private function progressHandler(event:ProgressEvent):void {
			trace("progressHandler: " + event);
		}
		
		private function soundCompleteHandler(event:Event):void {
			trace("soundCompleteHandler: " + event);
			//positionTimer.stop();
		}
		
		public static function getInstance():GameSound{
			if(!_inst)
				_inst = new GameSound(new SingletonEnforcer);
			return _inst;
		}
	}//end class
}
class SingletonEnforcer{}// ActionScript file