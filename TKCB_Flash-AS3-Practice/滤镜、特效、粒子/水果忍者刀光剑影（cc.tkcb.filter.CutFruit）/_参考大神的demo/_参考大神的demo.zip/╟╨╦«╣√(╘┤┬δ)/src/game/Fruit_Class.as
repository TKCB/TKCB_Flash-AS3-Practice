package game
{
	import flash.display.BitmapData;
	import flash.display.Graphics;
	import flash.geom.Matrix;
	/**
	 *  粒子 
	 * @author didi
	 * 
	 */
	public class Fruit_Class
	{
		/*
		* 
		*/
		public var x:Number;
		/*
		* 
		*/
		public var y:Number;
		/*
		* x速度  v:velocity速度，速率
		*/
		public var vx:Number;
		/*
		* y速度
		*/
		public var vy:Number;
		/*
		* 重力
		*/
		public var gravity:Number=0.5;
		/*
		* 摩擦力
		*/
		public var friction:Number=0.95;
		/*
		* radius半径
		*/
		public var radius:Number;
		
		public var lineColor:uint = 0xffffff * Math.random();//改变水果外轮廓线的颜色;
		public var color:uint = 0xffffff * Math.random();//水果的颜色
		
		public var _Fruitbmp:BitmapData;
		/*
		* 0代表 添加
		*/
		public var state:int=0;
		/*
		* 角度 模拟图片旋转用
		*/
		public var angle:Number=0;
		public var angle1:Number=0;
		public var angle2:Number=0;
		
		/*
		* 角度速度 
		*/
		public var Vangle:Number;
		/*
		* 矩阵
		*/
		public var matr:Matrix = new Matrix;
		
		public function Fruit_Class()
		{
		}
		/**
		 *  update 被主舞台时间帧控制，按Event.ENTER_FRAME时间事件而更新水果状态
		 *  当水果的y大于舞台的Y，那么代表该水果跳出舞台。数组要将其删除
		 */		
		public function update(grap:Graphics):void
		{
			vx *= friction;//
			x += vx;//加x 向 右方向
			vy += gravity;
			vy *= friction;//vy开始是个负数,为了让物体由Y坐标由下向上,但是乘以一个正数,慢慢的值就变成了正数,然后值就开始加,物体就开始由上向下
			y += vy;//按时间事件，舞台将先从Y坐标465。然后随着y值越来越小，由舞台下方飞入舞台，之后相反。Y轴下落
			angle += Vangle;
			//在主舞台中如果添加了水果那么随机水果图片 在主舞台中添加了该图片
			if(_Fruitbmp)//当添加了那么给图片处理
			{
				matr.identity();//将矩阵变成空
				//translate沿 x 和 y 轴平移矩阵，由 dx 和 dy 参数指定。dx 沿 x 轴向右移动的量（以像素为单位）。
				matr.translate( -_Fruitbmp.width / 2, -_Fruitbmp.height / 2);//根据水果图片的宽和高
				matr.rotate(angle);//旋转角度
				matr.scale(2 * radius / _Fruitbmp.width, 2 * radius / _Fruitbmp.width);//对矩阵应用缩放转换。x 轴乘以 sx，y 轴乘以 sy。 
				matr.translate(x, y);
				//beginBitmapFill用位图图像填充绘图区。可以重复或平铺位图以填充该区域。
				grap.beginBitmapFill(_Fruitbmp,matr,false,true);
			}else{
				grap.beginFill(color);//否则填充一种颜色。这个可以不用
			}
			/*
			* 添加
			*/
			if (state == 0)//添加
			{
				//画圆
				grap.moveTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
				grap.lineTo(x, y);
				grap.drawCircle(x, y, radius);
			}
			else//切割
			{
				angle1 += Vangle;
				angle2 += Vangle;
				//drawArc:切割后图片变成2半。 注释掉，那么图片没有变成2半，直接破碎   可有可无
				drawArc(grap, x, y, radius, (angle2 - angle1) * 180 / Math.PI, angle1 * 180 / Math.PI);
			}
			//grap.lineStyle(1,0xffffff,02);//显示出 图片的外边框线和 半径  什么也不写代表不显示
			grap.lineStyle();//什么也不写代表不显示
			
		}
		/*
		* drawArc:切割后图片变成2半。 注释掉，那么图片没有变成2半，直接破碎   可有可无
 		*/
		public function drawArc(grap:Graphics, nX:Number, nY:Number, nRadius:Number, nArc:Number, nStartingAngle:Number = 0):void
		{
			// The angle of each of the eight segments is 45 degrees (360 divided by eight),
			// which equals p/4 radians.
			//　　每一个角度的八段45度(360除以8人) 　　/ /这等于p / 4弧度
			if (nArc < 0)
			{
				nArc += 360;
			}
			if (nArc > 360)
			{
				nArc = 360;
			}
			nArc = Math.PI / 180 * nArc;
			var nAngleDelta:Number = nArc / 8;
			
			// Find the distance from the circle's center to the control points
			// for the curves.
			var nCtrlDist:Number = nRadius / Math.cos(nAngleDelta / 2);
			
			nStartingAngle *= Math.PI / 180;
			
			var nAngle:Number = nStartingAngle;
			var nCtrlX:Number;
			var nCtrlY:Number;
			var nAnchorX:Number;
			var nAnchorY:Number;
			
			var nStartingX:Number = nX + Math.cos(nStartingAngle) * nRadius;
			var nStartingY:Number = nY + Math.sin(nStartingAngle) * nRadius;
			
			// Move to the starting point, one radius to the right of the circle's center.
			grap.moveTo(nStartingX, nStartingY);
			// Repeat eight times to create eight segments.
			for (var i:Number = 0; i < 8; i++)
			{
				// Increment the angle by angleDelta (p/4) to create the whole circle (2p).
				nAngle += nAngleDelta;
				
				// The control points are derived using sine and cosine.
				nCtrlX = nX + Math.cos(nAngle - (nAngleDelta / 2)) * (nCtrlDist);
				nCtrlY = nY + Math.sin(nAngle - (nAngleDelta / 2)) * (nCtrlDist);
				
				// The anchor points (end points of the curve) can be found similarly to the
				// control points.
				nAnchorX = nX + Math.cos(nAngle) * nRadius;
				nAnchorY = nY + Math.sin(nAngle) * nRadius;
				
				// Draw the segment.
				grap.curveTo(nCtrlX, nCtrlY, nAnchorX, nAnchorY);
			}
		}
			/*
			* 切割  当切割线经过后，将图片分成2半
			*/
			public function cut(x1:Number, y1:Number, x2:Number, y2:Number):void
			{
				angle1 = Math.atan2(y1 - y, x1 - x);
				angle2 = Math.atan2(y2 - y, x2 - x);
				if (x1 > x2)
				{
					vx += 3;
					Vangle += 0.05;
				}
				else
				{
					vx -= 3;
					Vangle -= 0.05;
				}
			}
			
	}
}