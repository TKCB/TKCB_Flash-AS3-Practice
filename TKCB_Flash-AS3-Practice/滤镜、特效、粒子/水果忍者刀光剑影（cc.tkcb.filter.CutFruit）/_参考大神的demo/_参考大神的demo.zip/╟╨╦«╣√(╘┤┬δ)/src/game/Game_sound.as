package game
{
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.events.MouseEvent;
	import flash.events.ProgressEvent;
	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.net.URLRequest;
	public class Game_sound
	{
		private static var _inst:Game_sound;
		/**
		 *声音通道 
		 */		
		private var song:SoundChannel;
		/**
		 * 音乐控制 
		 */		
		private var soundFactory:Sound;
		/**
		 * 背景音乐 
		 */		
		private var music:Sound;
		/**
		 * 切割声音
		 */		
		private var cutSound:Sound;
		
		private var url:String = "res/mode.mp3";
		
		public function Game_sound(sing:SingletonEnforcer)
		{
			var request:URLRequest = new URLRequest("url");
			soundFactory = new Sound();
			soundFactory.addEventListener(Event.COMPLETE, completeHandler);
			soundFactory.addEventListener(Event.ID3, id3Handler);
			soundFactory.addEventListener(IOErrorEvent.IO_ERROR, ioErrorHandler);
			soundFactory.addEventListener(ProgressEvent.PROGRESS, progressHandler);
			soundFactory.load(request);
			
			music = new Sound();
			music.load(new URLRequest("res/mode.mp3"));
			//song = music.play(0,10000);//声音开始位置0,100000为时间，时间结束后，回复开始的第0位置
			
			
			cutSound = new Sound();
			cutSound.load(new URLRequest("res/asplode.mp3"));
		}
		/**
		 * 根据类型判断播放音乐   1切割 
		 * @param event
		 * 
		 */		
		public function playSound(type:int):void
		{
			switch(type)
			{
				case 0:
					song = music.play(0,10000);
					break;
				case 1:
					song = cutSound.play();
					break;
			}
		}
		private function completeHandler(event:Event):void
		{
			trace("completeHandler: " + event);
		}
		private function id3Handler(event:Event):void
		{
			trace("completeHandler: " + event);
		}
		private function ioErrorHandler(event:Event):void
		{
			trace("completeHandler: " + event);
		}
		private function progressHandler(event:ProgressEvent):void
		{
			trace("completeHandler: " + event);
		}
		public static function getInstance():Game_sound{
			if(!_inst)
				_inst = new Game_sound(new SingletonEnforcer);
			return _inst;
		}
	}
}
class SingletonEnforcer{}