package game
{
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Graphics;
	import flash.display.Shape;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.filters.GlowFilter;
	import flash.geom.ColorTransform;
	import flash.geom.Point;
	import flash.geom.Rectangle;
	import flash.text.TextField;
	import flash.text.TextFormat;
	
	import flashx.textLayout.elements.TextFlow;
	
	public class Game extends Sprite
	{
		private var time:int = 0;
		/*
		 * 鼠标在舞台的开始X位置
		 */
		private var lastX:Number;
		/*
		 * 鼠标在舞台的开始Y位置
		 */
		private var lastY:Number;
		/*
		 * 在舞台上画切割线的数组
		 */
		private var lines:Array = [];
		/*
		 * 切割水果后爆炸
		 */
		private var explodeArr:Array = [];
		/*
		 * 画 切割刀  shape 与 sprite的不同在于 shape没有交互不能添加侦听
		 */
		private var cutlayer:Shape = new Shape;
		private var flayer:Shape = new Shape;
		/*
		 * 为切割刀:创建一个具有指定的宽度和高度的 BitmapData 对象。
		 * 如果为 fillColor 参数指定一个值，则位图中的每个像素都将设置为该颜色。
		 */
		private var cutBmdLayer:BitmapData;
		/*
		 * 为水果层:创建一个具有指定的宽度和高度的 BitmapData 对象。
		 * 如果为 fillColor 参数指定一个值，则位图中的每个像素都将设置为该颜色。
		 */
		private var fruitBmdLayer:BitmapData;
		/*
		 * 颜色转换
		 *颜色转换不会应用于影片剪辑（如加载的 SWF 对象）的背景色，它们仅应用于附加到影片剪辑的图形和元件。
		 * 可使用 ColorTransform 类调整显示对象的颜色值。
		 */
		private var cutlayerCT:ColorTransform; //切割线
		private var fruitlayerCT:ColorTransform; //水果
		/*
		 * 添加三种随机背景
		 */
		[Embed(source='../../lib/bg.jpg')]
		private var bg1:Class
		private var bgimg1:BitmapData = (new bg1 as Bitmap).bitmapData;
		
		[Embed(source='../../lib/bg2.jpg')]
		private var bg2:Class
		private var bgimg2:BitmapData = (new bg2 as Bitmap).bitmapData;
		
		[Embed(source='../../lib/bg3.jpg')]
		private var bg3:Class
		private var bgimg3:BitmapData = (new bg3 as Bitmap).bitmapData;
		/*
		 * 添加 背景  9种水果
		 */
		[Embed(source='../../lib/fruit1.png')]
		private var fruit1:Class
		private var f1Img:BitmapData = (new fruit1 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit2.png')]
		private var fruit2:Class
		private var f2Img:BitmapData = (new fruit2 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit3.png')]
		private var fruit3:Class
		private var f3Img:BitmapData = (new fruit3 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit4.png')]
		private var fruit4:Class
		private var f4Img:BitmapData = (new fruit4 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit5.png')]
		private var fruit5:Class
		private var f5Img:BitmapData = (new fruit5 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit6.png')]
		private var fruit6:Class
		private var f6Img:BitmapData = (new fruit6 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit7.png')]
		private var fruit7:Class
		private var f7Img:BitmapData = (new fruit7 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit8.png')]
		private var fruit8:Class
		private var f8Img:BitmapData = (new fruit8 as Bitmap).bitmapData;
		[Embed(source='../../lib/fruit9.png')]
		private var fruit9:Class
		private var f9Img:BitmapData = (new fruit9 as Bitmap).bitmapData;
		//颜色随机数组  取不同的图片
		private var imgArray:Array = [f1Img, f2Img, f3Img, f4Img, f5Img, f6Img, f7Img, f8Img, f9Img];
		//声音
		private var _sound:Game_sound;
		//字体
		private var txt:TextField;
		//分数
		private var score:int = 0;
		private var lost:int = 0;
		
		/**
		 * @param w
		 * @param h
		 * @param randomBg背景随机值
		 */
		public function Game(w:Number, h:Number, randomBg:int) //randomBg 背景随机值
		{
			super();
			//字
			txt = new TextField();
			
			txt.multiline = true;
			txt.width = 250;
			txt.x = 5;
			txt.y = 440;
			txt.multiline = true;
			txt.textColor = 0xff0000;
			txt.mouseEnabled = false;
			var tfm:TextFormat = new TextFormat("宋体", 20);
			txt.defaultTextFormat = tfm;
			/*
			   txt.filters = [
			   //new GradientBevelFilter(8, 90, [0xffd21e, 0xff0000], [1, 1], [0xff*0.25,0xff*0.75], 5, 5, 1, 1, "inner", true),
			   new GlowFilter(0xffffff, 1, 2, 2, 5),
			   new GlowFilter(0,1,2,2,10)];
			 */
			
			//3种背景
			var view:Bitmap = new Bitmap(new BitmapData(w, h));
			var bmd:BitmapData = new BitmapData(w, h, true, 0);
			var rect:Rectangle = new Rectangle(0, 0, w, h);
			var pt:Point = new Point(0, 0);
			switch (randomBg)
			{ //3种背景
				case 0: 
					bmd.copyPixels(bgimg1, rect, pt);
					break;
				case 1: 
					bmd.copyPixels(bgimg2, rect, pt);
					break;
				case 2: 
					bmd.copyPixels(bgimg3, rect, pt);
					break;
			}
			view = new Bitmap(bmd);
			addChild(view);
			/*
			 * 可以再 w，h 465，,465的空间内添加 水果和切割线
			 * true 是 指定位图图像是否支持每个像素具有不同的透明度。默认值为 true
			 * 如果为false 将看不到背景了。
			 */
			fruitBmdLayer = new BitmapData(w, h, true, 0);
			addChild(new Bitmap(fruitBmdLayer));
			fruitlayerCT = new ColorTransform(1, 1, 1, 0.5);
			
			cutBmdLayer = new BitmapData(w, h, true, 0);
			var cutImage:Bitmap = new Bitmap(cutBmdLayer); //切割线
			addChild(cutImage);
			addChild(txt);
			
			//因为线是黑色，特此滤镜为红颜色边
			cutImage.filters = [new GlowFilter(0xff0000, 1, 16, 16, 2, 3, false, false)];
			
			//cutlayerFilter = new BlurFilter(2, 2, 3);
			//ColorTransform:用指定的颜色通道值和 Alpha 值为显示对象创建 ColorTransform 对象。
			cutlayerCT = new ColorTransform(1, 1, 1, 0);
			
			addEventListener(MouseEvent.MOUSE_DOWN, onClick_down, false, 0, true);
			addEventListener(Event.ENTER_FRAME, onFrame, false, 0, true);
		}
		
		/**
		 * @param e 按下按钮 记录当前的按下坐标  开始侦听移动鼠标和鼠标抬起
		 */
		private function onClick_down(e:MouseEvent):void
		{
			lastX = mouseX;
			lastY = mouseY;
			this.addEventListener(MouseEvent.MOUSE_MOVE, onClick_move, false, 0, true);
			this.addEventListener(MouseEvent.MOUSE_UP, onClick_up, false, 0, true);
		}
		private var line:Line_Class;
		
		/**
		 * @param e  点击后移动鼠标画切割线
		 */
		private function onClick_move(e:MouseEvent):void
		{
			line = new Line_Class();
			line.x1 = lastX;
			line.y1 = lastY;
			lastX = mouseX;
			lastY = mouseY;
			line.x2 = lastX;
			line.y2 = lastY;
			lines.push(line); //加入到切割线数组中
		}
		
		private function onClick_up(e:MouseEvent):void
		{
			this.removeEventListener(MouseEvent.MOUSE_MOVE, onClick_move);
			this.removeEventListener(MouseEvent.MOUSE_UP, onClick_up);
		}
		
		/**
		 * @param e Time更新。一直监听舞台
		 */
		
		private function onFrame(e:Event):void
		{
			//trace("Math.random() " +Math.random());
			var fruitLayer:Graphics = flayer.graphics; //fruitLayer水果shape
			fruitLayer.clear();
			
			for (var i:int = fruits.length - 1; i >= 0; i--) //fruits.length-1  如果不减去1  进来这个函数就会让水果类为null报错
			{
				var fruitClass:Fruit_Class = fruits[i];
				fruitClass.update(fruitLayer);
				if (fruitClass.y > _height) //判断是否已经 离开了界面内
				{
					if (fruitClass.state == 0) //添加水果
					{
						//分数减少1
						fruits.splice(i, 1);
					}
				}
			} //end 水果
			
			for (i = explodeArr.length - 1; i >= 0; i--)
			{
				fruitClass = explodeArr[i];
				fruitClass.update(fruitLayer);
				if (fruitClass.y > _height)
				{
					explodeArr.splice(i, 1);
				}
			} //end 爆炸
			
			cutlayer.graphics.clear(); //清除切割线
			
			for (i = lines.length - 1; i >= 0; i--) //i  值 没有  var 还是用的上面的 i
			{
				var line:Line_Class = lines[i]; //线数组中的第i个
				if (line.state == 0) //状态0，表示开始画线
				{
					for (var j:int = fruits.length - 1; j >= 0; j--)
					{
						fruitClass = fruits[j];
						//切割   切割线的开始坐标与结束坐标    与   水果的x，y 以及半径向交叉
						var intersectionOB:Object = intersection(line.x1, line.y1, line.x2, line.y2, fruitClass.x, fruitClass.y, fruitClass.radius);
						if (fruitClass.state == 0 && intersectionOB != null) //判断是否切割到
						{
							//声音
							Game_sound.getInstance().playSound(1);
							
							fruitClass.state = 1;
							fruitClass.cut(intersectionOB.x1, intersectionOB.y1, intersectionOB.x2, intersectionOB.y2);
							var fruitClass2:Fruit_Class = new Fruit_Class;
							fruitClass2.x = fruitClass.x;
							fruitClass2.y = fruitClass.y;
							fruitClass2.vx = fruitClass.vx;
							fruitClass2.vy = fruitClass.vy;
							fruitClass2.radius = fruitClass.radius;
							fruitClass2.Vangle = fruitClass.Vangle;
							//p2.lineColor = p.lineColor;//
							//p2.color = p.color;
							fruitClass2._Fruitbmp = fruitClass._Fruitbmp;
							fruitClass2.state = fruitClass.state;
							//正常情况下切割后，图片变2半，cut如果注释后，变1半，另一半粉碎.
							fruitClass2.cut(intersectionOB.x2, intersectionOB.y2, intersectionOB.x1, intersectionOB.y1);
							fruits.push(fruitClass2);
							score++;
							rubbish(fruitClass.x, fruitClass.y, fruitClass._Fruitbmp);
						}
					}
				}
				
				line.state++;
				if (line.state > 5)
				{
					lines.splice(i, 1);
				}
				cutlayer.graphics.lineStyle(i / 3, 0xffffff, 1, true, "none", "round", "round", 1);
				cutlayer.graphics.moveTo(line.x1, line.y1);
				cutlayer.graphics.lineTo(line.x2, line.y2);
			} //end 切割线
			/*
			 * 没有这个 则 切割线不消失
			 * 使用 ColorTransform 对象调整位图图像的指定区域中的颜色值。
			 * 如果矩形与位图图像的边界匹配，则此方法将转换整个图像的颜色值。
			 */
			cutBmdLayer.colorTransform(cutBmdLayer.rect, cutlayerCT);
			cutBmdLayer.draw(cutlayer);
			
			//水果层
			fruitBmdLayer.colorTransform(fruitBmdLayer.rect, fruitlayerCT);
			fruitBmdLayer.draw(flayer);
			txt.text = "分数:" + score + "时间:" + int(time / stage.frameRate);
			time++; //时间
			if (Math.random() < Math.atan(0.02 + time / 100000))
			{
				addFruit();
			}
		}
		/*
		 * 水果数组 将添加的水果放入数组中
		 */
		private var fruits:Array = [];
		private var weith:int = 768;
		private var _height:int = 800;
		
		/**
		 * 添加水果  区别每个水果的位置不同    随机
		 */
		private function addFruit():void
		{
			var fruit:Fruit_Class = new Fruit_Class();
			fruit.x = weith * (0.3 + 0.4 * Math.random());
			fruit.y = _height;
			fruit.vx = 5 * (Math.random() - .5);
			fruit.vy = -(20 + 20 * Math.random()); //y开始的时候为负值 是由画面下到画面上方的
			fruit.angle = Math.PI * 2 * Math.random();
			fruit.Vangle = 0.1 * (Math.random() - 0.5);
			fruit.radius = 15 + 25 * Math.random(); //半径决定图片的尺寸缩放大小
			fruit._Fruitbmp = imgArray[int(imgArray.length * Math.random())]
			fruits.push(fruit);
		}
		
		/**
		 * 交叉   碰撞   返回 Object
		 * 数学知识，求直线和园的交点  网上找
		 */
		private function intersection(x1:Number, y1:Number, x2:Number, y2:Number, x3:Number, y3:Number, r:Number):Object
		{
			var A:Number = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
			var B:Number = 2 * ((x2 - x1) * (x1 - x3) + (y2 - y1) * (y1 - y3));
			var C:Number = x3 * x3 + y3 * y3 + x1 * x1 + y1 * y1 - 2 * (x3 * x1 + y3 * y1) - r * r;
			var bb_plus_4ac:Number = B * B - 4 * A * C;
			if (bb_plus_4ac > 0)
			{
				var sqrt:Number = Math.sqrt(bb_plus_4ac);
				var u1:Number = (-B + sqrt) / 2 / A;
				var u2:Number = (-B - sqrt) / 2 / A;
				var cutx1:Number = x1 + (x2 - x1) * u1;
				var cuty1:Number = y1 + (y2 - y1) * u1;
				var cutx2:Number = x1 + (x2 - x1) * u2;
				var cuty2:Number = y1 + (y2 - y1) * u2;
				var obj:Object = {x1: cutx1, y1: cuty1, x2: cutx2, y2: cuty2};
				if (u1 > 0 && u1 < 1)
				{
					return obj;
				}
				if (u2 > 0 && u2 < 1)
				{
					return obj;
				}
			}
			return null;
		}
		
		/**
		 * 切割水果后爆炸  在onFream函数中每帧事件动作
		 */
		private function rubbish(x:Number, y:Number, bmd:BitmapData):void
		{
			var rubb:int = 19; //100*Math.random();//爆炸的粉末数量
			while (--rubb > 0)
			{
				var particle:Fruit_Class = new Fruit_Class();
				var rubbx:int = bmd.width * Math.random(); //爆炸粉末X
				var rubby:int = bmd.height * Math.random(); //爆炸粉末Y
				//getPixel32返回一个 ARGB 颜色值，它包含 Alpha 通道数据和 RGB 数据。
				//此方法与 getPixel() 方法类似，后者返回没有 Alpha 通道数据的 RGB 颜色。 
				//getPixel32  与  getPixel 不同地方在于  getpixel是没有Alpha
				var color:uint = bmd.getPixel32(rubbx, rubby);
				particle.color = color;
				particle.x = x;
				particle.y = y;
				particle.radius = 1 + 1 * Math.random();
				particle.angle = Math.PI * 2 * Math.random();
				particle.Vangle = 0.1 * (Math.random() - 0.5);
				var speed:Number = 10 * Math.random();
				particle.vx = speed * Math.cos(particle.angle);
				particle.vy = speed * Math.sin(particle.angle);
				explodeArr.push(particle);
			}
		}
	}
}