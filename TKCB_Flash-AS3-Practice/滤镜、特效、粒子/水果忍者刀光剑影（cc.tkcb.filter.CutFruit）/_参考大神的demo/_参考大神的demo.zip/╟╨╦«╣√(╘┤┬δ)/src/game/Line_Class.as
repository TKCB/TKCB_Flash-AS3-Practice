package game
{
	public class Line_Class
	{
		/*
		* 直线的 起始坐标和结束坐标 
		*/
		public var x1:Number;
		public var y1:Number;
		public var x2:Number;
		public var y2:Number;
		/*
		* state 0 表示画线  
		*/
		public var state:int = 0;
		
		public function Line_Class()
		{
		}
		public function get length():Number {
			return Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		}
	}
}