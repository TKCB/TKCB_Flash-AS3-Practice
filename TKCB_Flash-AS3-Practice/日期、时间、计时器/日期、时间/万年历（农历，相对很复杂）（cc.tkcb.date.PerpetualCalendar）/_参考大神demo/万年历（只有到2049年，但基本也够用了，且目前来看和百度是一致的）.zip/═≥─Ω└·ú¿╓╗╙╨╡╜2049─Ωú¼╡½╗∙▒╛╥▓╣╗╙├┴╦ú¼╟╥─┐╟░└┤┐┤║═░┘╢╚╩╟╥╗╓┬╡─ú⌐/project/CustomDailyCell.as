﻿package project{
	
	import flash.display.*;
	import flash.events.MouseEvent;
	import  flash.text.*
	public class CustomDailyCell extends MovieClip {
		private var _OBJ:Object
		private var selected:Boolean = false
		private var Ftxtfmt:TextFormat
		private var Ntxtfmt:TextFormat
		private var _ID:Number=0
		private var content:String=""
		public function CustomDailyCell() {
 Ftxtfmt = new TextFormat
 Ftxtfmt.color = 0xff0000
 
 Ntxtfmt = new TextFormat
 Ntxtfmt.color = 0x000000
 
			this.gotoAndStop(1);
			this.buttonMode = true
			this.mouseChildren = false
			this.doubleClickEnabled=true
			this.addEventListener(MouseEvent.MOUSE_OVER,cellmouseover)
			this.addEventListener(MouseEvent.MOUSE_OUT,cellmouseout)
			this.addEventListener(MouseEvent.DOUBLE_CLICK, celldbclick)
			CustomDailyToolTip.Add(this)
			icon.visible=false
		}
		private function cellmouseover(e:MouseEvent) {
			if(OBJ==null || Selected) return
			
			this.gotoAndStop(3);
			
			}	
			private function celldbclick(e:MouseEvent=null) {
			if(OBJ==null) return
			//AddDaily.CallBack=detailok
			if (ID == 0) {
		//AddDaily.AddNew(OBJ.sYear+"-"+(OBJ.sMonth)+"-"+OBJ.sDay)
		}else {
			//trace("Edit "+ID)
				//AddDaily.Edit(ID)
				}
			}
			
			
			private function 	detailok() {
				
				//SetDailyInfo(AddDaily.ID,AddDaily.DescribeBlog)
				}
			
			
		private function cellmouseout(e:MouseEvent) {
			if(OBJ==null) return
			Selected=selected
			
			}
		public function get OBJ():Object { return _OBJ; }
		
		public function set OBJ(value:Object):void 
		{
			
				ClearDailyInfo()
	_OBJ = value;
	if(value == null) {
	
	yinlitext.text=""
	yinlijieritext.text=""
	jieqitext.text=""
	daytext.text = ""
	this.gotoAndStop(6);
	this.parent.setChildIndex(this,0)

	return 
	
	}
	
	
	var txtf:TextFormat 
if(value.lDay == 1) {
		yinlitext.text=""+value.lZMonth
	}else {
			yinlitext.text=""+value.lZDay
		}
			daytext.text=""+value.sDay
		
			yinlijieritext.text = "" + value.solarTerms
			
			if (value.lunarFestival != "" && value.lunarFestival != "undefined") {
				jieqitext.text = "" + value.lunarFestival
				
				 txtf = jieqitext.getTextFormat();
				txtf.color=0xff0000
				jieqitext.setTextFormat(txtf)
				
				}else {
					
			jieqitext.text = "" + value.solarFestival
			
			 txtf = jieqitext.getTextFormat();
				txtf.color=0x0066FF
				jieqitext.setTextFormat(txtf)
				
				
				}
			
			
		if (OBJ.color == 'red') {
			daytext.setTextFormat(Ftxtfmt)
			yinlitext.setTextFormat(Ftxtfmt)
			}else {
				
					daytext.setTextFormat(Ntxtfmt)
					yinlitext.setTextFormat(Ntxtfmt)
				}
			Selected=selected
		}
		
		public function get Selected():Boolean { return selected; }
		
		public function set Selected(value:Boolean):void 
		{
			
			
			selected = value;
			if (value) {
				
				this.gotoAndStop(4)
				} else {
				if (OBJ != null) {
					
					if (OBJ.isToday == true) {
					
				this.gotoAndStop(5)
						}else {
							
							if(OBJ.sDay%2==0){
							this.gotoAndStop(1)
							}else {
								this.gotoAndStop(2)
								}
							
							}
					}else {
						this.gotoAndStop(6)
						
						}
					
					
				}
		}
		public function SetDailyInfo(id:Number, str:String) {
			ID = id;
			Content = str;
			
			if (id == 0 || isNaN(id) ) {
				icon.visible = false
				
				
					
					
				
				}else {
					
					if (str == "" || str=="undefined" || str==" ") {
				icon.visible=false
				}else {
					icon.visible = true
					}
				
					}
					
					
					
					
			
			}
		
			
		public function ClearDailyInfo() {
		SetDailyInfo(0,"")
			
			
			
			}
		
		public function get ID():Number { return _ID; }
		
		public function set ID(value:Number):void 
		{
			_ID = value;
			
			
		}
		
		public function get Content():String { return content; }
		
		public function set Content(value:String):void 
		{
			content = value;
			
			
			dailytext.text=""+content
		}
		

	}
}