﻿package project{
	
	import flash.display.*;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import  flash.text.*
	import flash.utils.setInterval
	public class CustomDailyToolTip extends MovieClip {
		private  static var _MC:CustomDailyToolTipUI	
		private static var _ROOT:DisplayObjectContainer
		private static var jiange:Number
		private static  var MarginTime:Number=60
		public function CustomDailyToolTip() {
 
			
		}
		
		private static function ccc(e:Event) {
			jiange--
			if (jiange <= 0) {
				
					if (_MC != null) {
				
					ROOT.removeChild(_MC)
					_MC=null
					}
					
					e.target.removeEventListener(MouseEvent.MOUSE_MOVE,mousemove)
					e.target.removeEventListener(MouseEvent.MOUSE_OUT,mousemout)
						e.target.removeEventListener(Event.ENTER_FRAME, ccc);
				
				}
			
			
			}
		public static function  Add(target:CustomDailyCell) {
			
			target.addEventListener(MouseEvent.MOUSE_OVER,cellmouseover)
			
			}
			
			private static function Move() {
					jiange=MarginTime
				ROOT.setChildIndex(_MC, ROOT.numChildren - 1)
					var temx:Number = ROOT.mouseX+15
					var temy:Number = ROOT.mouseY+15
					
					if ((temx + _MC.width) > ROOT.stage.stageWidth) {
						temx=ROOT.stage.stageWidth-_MC.width
						}
						
						if ((temy + _MC.height) > ROOT.stage.stageHeight) {
						temy=ROOT.stage.stageHeight-_MC.height
						}
							
					_MC.x=temx
					_MC.y=temy
				
				}
			public static function cellmouseover(e:MouseEvent) {
				if (ROOT == null) return 
				if (e.target.OBJ == null) return 
				//jiange=MarginTime
				var obj:Object=e.target.OBJ as Object
				if (_MC == null) {
					_MC = new CustomDailyToolTipUI
					_MC.mouseChildren = false
					_MC.mouseEnabled = false
					
					_MC.riqi.text=obj.sYear+"年"+obj.sMonth+"月"+obj.sDay+"号"
					_MC.xinqi.text="星期"+obj.week
					_MC.nongli.text="农历"+obj.lYear+"年"+obj.lZMonth+""+obj.lZDay
					_MC.tiangan.text=""+obj.cYear+"年 "+obj.cMonth+"月 "+obj.cDay+"日"
					
					
					
					
					if (obj.lunarFestival != "" && obj.lunarFestival != "undefined") {
				_MC.jieqitext.text = "" + obj.lunarFestival
				
				
				
				}else {
					
			_MC.jieqitext.text = "" + obj.solarFestival
			
			
				
				
				}
				
				if (obj.solarTerms != "" && obj.solarTerms != "undefined") {
					_MC.jieqitext.text = "" + obj.solarTerms
					}
				
				_MC.jieqitext.text = obj.solarTerms+" "+obj.solarFestival+" "+obj.lunarFestival
				
					ROOT.addChild(_MC)
					}
				 Move()
					
					e.target.addEventListener(MouseEvent.MOUSE_MOVE,mousemove)
					e.target.addEventListener(MouseEvent.MOUSE_OUT,mousemout)
					e.target.addEventListener(Event.ENTER_FRAME, ccc);
				
				}
				
					public static function mousemove(e:MouseEvent) {
							if (_MC == null) return 
							Move()
					
					
						}
					
						
						public static function mousemout(e:MouseEvent=null) {
							if (_MC != null) {
				
					ROOT.removeChild(_MC)
					_MC=null
					}
				
					e.target.removeEventListener(MouseEvent.MOUSE_MOVE,mousemove)
					e.target.removeEventListener(MouseEvent.MOUSE_OUT,mousemout)
					
					e.target.removeEventListener(Event.ENTER_FRAME, ccc);
						
						}	
						
						
				static public function get ROOT():DisplayObjectContainer { return _ROOT; }
				
				static public function set ROOT(value:DisplayObjectContainer):void 
				{
					_ROOT = value;
				}

	}
}