﻿package project{
	import adobe.utils.CustomActions;
	//import com.yahoo.astra.accessibility.EventTypes;
	import flash.display.*;
	import flash.filters.DropShadowFilter;
	import flash.net.URLLoader;
	import flash.net.URLRequest;
	import flash.events.*;
	import flash.text.*;
	import flash.net.*;
	import flash.text.*
	import fl.controls.ComboBox;
	/*
	
	日历类，万年历。
		作者：赵军华
		邮箱：zjhty2008@163.com
		qq：68161178
	
	*/
	public class CustomDaily extends MovieClip {
	
		


/*****************************************************************************
                                   日期资料
*****************************************************************************/

private var lunarInfo=new Array(
0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,
0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,
0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,
0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,
0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,
0x06ca0,0x0b550,0x15355,0x04da0,0x0a5b0,0x14573,0x052b0,0x0a9a8,0x0e950,0x06aa0,
0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,
0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b6a0,0x195a6,
0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,
0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,
0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,
0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,
0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,
0x05aa0,0x076a3,0x096d0,0x04bd7,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,
0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0,
0x14b63);

private var solarMonth=new Array(31,28,31,30,31,30,31,31,30,31,30,31);
private var GetDateURL:String="http://3cf/moneybook/webservice/saveclass.asp?action=GetBlog";
private var Gan=new Array("甲","乙","丙","丁","戊","己","庚","辛","壬","癸");
private var Zhi=new Array("子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥");
private var Animals=new Array("鼠","牛","虎","兔","龙","蛇","马","羊","猴","鸡","狗","猪");
private var solarTerm = new Array("小寒","大寒","立春","雨水","惊蛰","春分","清明","谷雨","立夏","小满","芒种","夏至","小暑","大暑","立秋","处暑","白露","秋分","寒露","霜降","立冬","小雪","大雪","冬至");
private var sTermInfo = new Array(0,21208,42467,63836,85337,107014,128867,150921,173149,195551,218072,240693,263343,285989,308563,331033,353350,375494,397447,419210,440795,462224,483532,504758);
private var nStr1 = new Array('日','一','二','三','四','五','六','七','八','九','十');
private var nStr2 = new Array('初','十','廿','卅','□');
private var monthName = new Array("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC");
private var firstWeek:Number=0
private var Query:Boolean=false
//国历节日 *表示放假日
private var sFtv = new Array(
"0101*元旦节",
"0202 世界湿地日",
"0210 国际气象节",
"0214 情人节",
"0301 国际海豹日",
"0303 全国爱耳日",
"0305 学雷锋纪念日",
"0308 妇女节",
"0312 植树节 孙中山逝世纪念日",
"0314 国际警察日",
"0315 消费者权益日",
"0317 中国国医节 国际航海日",
"0321 世界森林日 消除种族歧视国际日 世界儿歌日",
"0322 世界水日",
"0323 世界气象日",
"0324 世界防治结核病日",
"0325 全国中小学生安全教育日",
"0330 巴勒斯坦国土日",
"0401 愚人节 全国爱国卫生运动月(四月) 税收宣传月(四月)",
"0407 世界卫生日",
"0422 世界地球日",
"0423 世界图书和版权日",
"0424 亚非新闻工作者日",
"0501*劳动节",
"0502*劳动节假日",
"0503*劳动节假日",
"0504 青年节",
"0505 碘缺乏病防治日",
"0508 世界红十字日",
"0512 国际护士节",
"0515 国际家庭日",
"0517 国际电信日",
"0518 国际博物馆日",
"0520 全国学生营养日",
"0523 国际牛奶日",
"0531 世界无烟日", 
"0601 国际儿童节",
"0605 世界环境保护日",
"0606 全国爱眼日",
"0617 防治荒漠化和干旱日",
"0623 国际奥林匹克日",
"0625 全国土地日",
"0626 国际禁毒日",
"0701 香港回归纪念日 中共诞辰 世界建筑日",
"0702 国际体育记者日",
"0707 抗日战争纪念日",
"0711 世界人口日",
"0730 非洲妇女日",
"0801 建军节",
"0808 中国男子节(爸爸节)",
"0815 抗日战争胜利纪念",
"0908 国际扫盲日 国际新闻工作者日",
"0909 毛泽东逝世纪念",
"0910 中国教师节", 
"0914 世界清洁地球日",
"0916 国际臭氧层保护日",
"0918 九·一八事变纪念日",
"0920 国际爱牙日",
"0927 世界旅游日",
"0928 孔子诞辰",
"1001*国庆节 世界音乐日 国际老人节",
"1002*国庆节假日 国际和平与民主自由斗争日",
"1003*国庆节假日",
"1004 世界动物日",
"1006 老人节",
"1008 全国高血压日 世界视觉日",
"1009 世界邮政日 万国邮联日",

"1010 辛亥革命纪念日 世界精神卫生日",
"1013 世界保健日 国际教师节",
"1014 世界标准日",
"1015 国际盲人节(白手杖节)",
"1016 世界粮食日",
"1017 世界消除贫困日",
"1022 世界传统医药日",
"1024 联合国日",
"1031 世界勤俭日",
"1107 十月社会主义革命纪念日",
"1108 中国记者日",
"1109 全国消防安全宣传教育日",
"1110 世界青年节",
"1111 国际科学与和平周(本日所属的一周)",
"1112 孙中山诞辰纪念日",
"1114 世界糖尿病日",
"1117 国际大学生节 世界学生节",
"1120*彝族年",
"1121*彝族年 世界问候日 世界电视日",
"1122*彝族年",
"1129 国际声援巴勒斯坦人民国际日",
"1201 世界艾滋病日",
"1203 世界残疾人日",
"1205 国际经济和社会发展志愿人员日",
"1208 国际儿童电视日",
"1209 世界足球日",
"1210 世界人权日",
"1212 西安事变纪念日",
"1213 南京大屠杀(1937年)纪念日！紧记血泪史！",
"1220 澳门回归纪念",
"1221 国际篮球日",
"1224 平安夜",
"1225 圣诞节",
"1226 毛泽东诞辰纪念")

//农历节日 *表示放假日
private var lFtv = new Array(
"0101*春节",
"0102*春节",
"0103*春节",
"0115 元宵节",
"0505*端午节",
"0624*火把节",
"0625*火把节",
"0626*火把节",
"0707 七夕情人节",
"0715 中元节",
"0815 中秋节",
"0909 重阳节",
"1208 腊八节",
"1223 小年",
"0100 除夕")

//某月的第几个星期几
private var wFtv = new Array(
"0150 世界麻风日", //一月的最后一个星期日（月倒数第一个星期日）
"0520 国际母亲节",
"0530 全国助残日",
"0630 父亲节",
"0730 被奴役国家周",
"0932 国际和平日",
"0940 国际聋人节 世界儿童日",
"0950 世界海事日",
"1011 国际住房日",
"1013 国际减轻自然灾害日(减灾日)",
"1144 感恩节")
private var Today:Date = new Date();
var tY:Number 
var tM:Number 
var tD:Number 
private var SelectedDate:Number = 1
private var SelectedYear:Number = 2009
private var SelectedMonth:Number=5
private var CellArray:Array = new Array
private var IsLoading:Boolean=false
private var thingsmc:MovieClip
		public function CustomDaily() {
			
			
			//if (Fun.MoneyLoader != null) {
				//GetDateURL=Fun.Config.GetDateURL
			
				

				//}
				
				
				
				
				
				
 Today = new Date();
			 tY = Today.getFullYear();
 tM = Today.getMonth();
 tD = Today.getDate();
			
 
			
			thingsmc = new MovieClip
			thingsmc.y=60
			addChildAt(thingsmc,numChildren-2)
			initcell()
			
			
			totoday()
			
			
			
	
	
	
	
	
	
	
		}
		
		private function selectCell(cell:CustomDailyCell) {
			if (cell.OBJ == null) return
			if(cell.Selected) return 
			SelectedDate = cell.OBJ.sDay
			for (var i:int = 0; i < thingsmc.numChildren; i++ ) {
				
				var temcell:CustomDailyCell = thingsmc.getChildAt(i) as CustomDailyCell
				
				if (temcell == cell) {
					temcell.Selected=true
					}else {
						
						temcell.Selected=false
						}
				}
			}
			
			private function get SelectedCell():CustomDailyCell {
				
				var temcell:CustomDailyCell 
				for (var i:int = 0; i < thingsmc.numChildren; i++ ) {
				
				temcell = thingsmc.getChildAt(i) as CustomDailyCell
				
				if (temcell.Selected) {
					return temcell
					}
					
					
					
					
				}
				return temcell
				
				
				}
		private function cellclick(e:MouseEvent) {
			
			var cell:CustomDailyCell=e.target as CustomDailyCell
			if(cell.OBJ==null) return
			
			selectCell(cell)
			
			
			
			}
		private function initcell() {
			CellArray = []
			var i:int
			for (i = 0; i < 42; i++) {
				
				var cell:CustomDailyCell = new CustomDailyCell;
				
				cell.x=(i%7)*(cell.width-1)
				cell.y=Math.floor(i/7)*(cell.height-1)
				thingsmc.addChild(cell);
				CellArray.push(cell)
				cell.addEventListener(MouseEvent.CLICK,cellclick)
				}
			 
				 var ylis:ComboBox
				 var mlis:ComboBox
				 ylis=yearlist
				 mlis=monthlist
				 trace(ylis.name)
			for ( i = 1900; i < 2050;i++ ){	
	ylis.addItem( { label:i + "年", data:i } )		
	
	 
			}
				 
				
			for ( i = 0; i < 12;i++ ){	
	mlis.addItem({label:(i+1)+"月",data:i})			
			}
			preyear.Label="上一年"
			premonth.Label="上一月"
			nextmonth.Label="下一月"
			nextyear.Label="下一年"
			today.Label="今天"
					preyear.CallBack=	prey		
					premonth.CallBack=	prem
					nextyear.CallBack=	nexty		
					nextmonth.CallBack =	nextm		
					today.CallBack =	totoday		
					
					
					yearlist.addEventListener(Event.CHANGE,changeCld)
					monthlist.addEventListener(Event.CHANGE, changeCld)
					
					
		 
					
	CustomMune.Add(this, "写日记", witelog);
	CustomMune.Add(this, "上一月", prem);
	CustomMune.Add(this, "下一月", nextm);
	CustomMune.Add(this, "上一年", prey);
	CustomMune.Add(this, "下一年", nexty);
	CustomMune.Add(this, "今天", totoday);
	
	
	
			}
			
			
		private function witelog(e:MouseEvent = null) {
			var cell = SelectedCell
			if(cell==null) return 
			if(cell.OBJ==null) return
			//AddDaily.CallBack=detailok
			if (cell.ID == 0) {
		//AddDaily.AddNew(cell.OBJ.sYear+"-"+(cell.OBJ.sMonth)+"-"+cell.OBJ.sDay)
		}else {
			//trace("Edit "+ID)
				//AddDaily.Edit(cell.ID)
				}
			}
			
			
			
			private function detailok() {
				if(SelectedCell==null) return 
				//SelectedCell.SetDailyInfo(AddDaily.ID,AddDaily.BlogContent)
			}
			
			
			
			
				private function totoday() {
				var item
					var d:Date = new Date()
					var i:int
		
					
					for ( i= 0; i < yearlist.length; i++ ) {
						item=yearlist.getItemAt(i)
						if (item.data == d.getFullYear()) {
							
							yearlist.selectedIndex = i
							break;
							}
						}
						
							for ( i= 0; i <monthlist.length; i++ ) {
							item=monthlist.getItemAt(i)
						if (item.data == d.getMonth()) {
							
							monthlist.selectedIndex = i
							break;
							}
						}
					
					changeCld()
				}
				
				
				
				
			private function prey() {
				if(yearlist.selectedIndex<=0) return 
				yearlist.selectedIndex=yearlist.selectedIndex-1
				changeCld()
				}
			
			private function nexty() {
				if(yearlist.selectedIndex>=(2049-1900)) return 
				yearlist.selectedIndex=yearlist.selectedIndex+1
					changeCld()
				}	
			private function prem() {
				if(monthlist.selectedIndex<=0) return 
				monthlist.selectedIndex=monthlist.selectedIndex-1
					changeCld()
				}
			
			private function nextm() {
				if(monthlist.selectedIndex>=11) return 
				monthlist.selectedIndex=monthlist.selectedIndex+1
					changeCld()
				}
			
			
			
//============================== 阴历属性
function calElement(sYear,sMonth,sDay,week,lYear,lMonth,lDay,isLeap,cYear,cMonth,cDay):Object {
var obj:Object=new Object
obj.isToday    = false;
//瓣句
obj.sYear      = sYear;   //公元年4位数字
obj.sMonth     = sMonth;  //公元月数字
obj.sDay       = sDay;    //公元日数字
obj.week       = nStr1[week];    //星期, 1个中文
obj.Dweek       = week;    //星期, 1数字
//农历
obj.lYear      = lYear;   //公元年4位数字
obj.lMonth     = lMonth;  //农历月数字
obj.lDay       = (lDay);    //农历日数字
obj.lZDay       = this.cDay(lDay);    //农历日中文

var id :String=""
if(lMonth <= 10) {
	id=nStr1[lMonth]
	}else {
		id=nStr1[10]+nStr1[lMonth%10+1]
		
		}
if(lDay==1) //显示农历月
obj.lZMonth =(isLeap?'闰':'') + id + '月' + (monthDays(lYear,lMonth)==29?'小':'大');
else //显示农历日
obj.lZMonth = id+ '月'




obj.isLeap     = isLeap;  //是否为农历闰月?
//八字
obj.cYear      = cYear;   //年柱, 2个中文
obj.cMonth     = cMonth;  //月柱, 2个中文
obj.cDay       = cDay;    //日柱, 2个中文

obj.color      = '';
if(week == 0 || week == 6) {
	obj.color      = 'red';
	}
obj.lunarFestival = ''; //农历节日
obj.solarFestival = ''; //公历节日
obj.solarTerms    = ''; //节气
return obj
}

//===== 某年的第n个节气为几日(从0小寒起算)
function sTerm(y,n) {
var offDate = new Date( ( 31556925974.7*(y-1900) + sTermInfo[n]*60000  ) + Date.UTC(1900,0,6,2,5) );
return(offDate.getUTCDate());
}




//==============================返回公历 y年某m+1月的天数
function solarDays(y:Number,m:Number) {
if(m==1)
return(((y%4 == 0) && (y%100 != 0) || (y%400 == 0))? 29: 28);
else
return(solarMonth[m]);
}
//============================== 传入 offset 返回干支, 0=甲子
function cyclical(num) {
return(Gan[num%10]+Zhi[num%12]);
}


//====================================== 返回农历 y年m月的总天数
function monthDays(y,m) {
return( (lunarInfo[y-1900] & (0x10000>>m))? 30: 29 );
}

//====================================== 返回农历 y年的总天数
function lYearDays(y) {
var i, sum = 348;
for(i=0x8000; i>0x8; i>>=1) sum += (lunarInfo[y-1900] & i)? 1: 0;
return(sum+leapDays(y));
}

//====================================== 返回农历 y年闰月的天数
function leapDays(y) {
if(leapMonth(y))  return((lunarInfo[y-1900] & 0x10000)? 30: 29);
else return(0);
}

//====================================== 返回农历 y年闰哪个月 1-12 , 没闰返回 0
function leapMonth(y) {
return(lunarInfo[y-1900] & 0xf);
}


//====================================== 算出农历, 传入日期控件, 返回农历日期控件
//                                       该控件属性有 .year .month .day .isLeap
function Lunar(objDate:Date):Object {
var obj:Object=new Object
var i, leap=0, temp=0;
var offset   = (Date.UTC(objDate.getFullYear(),objDate.getMonth(),objDate.getDate()) - Date.UTC(1900,0,31))/86400000;

for(i=1900; i<2050 && offset>0; i++) { temp=lYearDays(i); offset-=temp; }

if(offset<0) { offset+=temp; i--; }

obj.year = i;

leap = leapMonth(i); //闰哪个月
obj.isLeap = false;

for(i=1; i<13 && offset>0; i++) {
//闰月
if(leap>0 && i==(leap+1) && obj.isLeap==false)
{ --i; obj.isLeap = true; temp = leapDays(obj.year); }
else
{ temp = monthDays(obj.year, i); }

//解除闰月
if(obj.isLeap==true && i==(leap+1)) obj.isLeap = false;

offset -= temp;
}

if(offset==0 && leap>0 && i==leap+1)
if(obj.isLeap)
{ obj.isLeap = false; }
else
{ obj.isLeap = true; --i; }

if(offset<0){ offset += temp; --i; }

obj.month = i;
obj.day = offset + 1;


return obj
}




//============================== 返回阴历控件 (y年,m+1月)
/*
功能说明: 返回整个月的日期资料控件

使用方式: OBJ = new calendar(年,零起算月);

OBJ.length      返回当月最大日
OBJ.firstWeek   返回当月一日星期

由 OBJ[日期].属性名称 即可取得各项值

OBJ[日期].isToday  返回是否为今日 true 或 false

其他 OBJ[日期] 属性参见 calElement() 中的注解
*/
function calendar(y:Number,m:Number) :Array{
var array:Array=new Array
var sDObj:Date, lDObj:Object, lY, lM, lD=1, lL, lX=0, tmp1:Number, tmp2, tmp3;
var cY, cM, cD; //年柱,月柱,日柱
var lDPOS = new Array(3);
var n = 0;
var firstLM = 0;
 
sDObj = new Date(y,m,1,0,0,0,0);    //当月一日日期
var length:Number    = solarDays(y,m);    //公历当月天数
//var firstWeek:Number = sDObj.getDay();    //公历当月1日星期几
firstWeek=sDObj.getDay();
////////年柱 1900年立春后为庚子年(60进制36)
if(m<2) cY=cyclical(y-1900+36-1);
else cY=cyclical(y-1900+36);
var term2=sTerm(y,2); //立春日期

////////月柱 1900年1月小寒以前为 丙子月(60进制12)
var firstNode = sTerm(y,m*2) //返回当月「节」为几日开始
cM = cyclical((y-1900)*12+m+12);

//当月一日与 1900/1/1 相差天数
//1900/1/1与 1970/1/1 相差25567日, 1900/1/1 日柱为甲戌日(60进制10)
var dayCyclical = Date.UTC(y,m,1,0,0,0,0)/86400000+25567+10;
 for(var i=0;i<length;i++) {
 if(lD>lX) {
sDObj = new Date(y,m,i+1);    //当月一日日期

lDObj =  Lunar(sDObj) as Object;     //农历


lY    = lDObj.year;           //农历年

lM    = lDObj.month;          //农历月
lD    = lDObj.day;            //农历日
lL    = lDObj.isLeap;         //农历是否闰月
lX    = lL? leapDays(lY): monthDays(lY,lM); //农历当月最后一天

if(n==0) firstLM = lM;
lDPOS[n++] = i-lD+1;
}
 //依节气调整二月分的年柱, 以立春为界
if(m==1 && (i+1)==term2) cY=cyclical(y-1900+36);
//依节气月柱, 以「节」为界
if((i+1)==firstNode) cM = cyclical((y-1900)*12+m+13);
//日柱
cD = cyclical(dayCyclical+i);

//sYear,sMonth,sDay,week,
//lYear,lMonth,lDay,isLeap,
//cYear,cMonth,cDay
array.push(calElement(y, m+1, i+1, (i+firstWeek)%7,lY, lM, lD++, lL,cY ,cM, cD ));
}



//节气
tmp1=sTerm(y,m*2  )-1;
tmp2 = sTerm(y, m * 2 + 1) - 1;

array[tmp1].solarTerms = solarTerm[m * 2];

array[tmp2].solarTerms = solarTerm[m * 2 + 1];

if(m==3) array[tmp1].color = 'red'; //清明颜色






//公历节日
for(i in sFtv) {
	var str:String=sFtv[i]
	var d1:Number = Number(str.substr(0, 2));
	var d2:Number = Number(str.substr(2, 2));
	var d3:String = str.substr(4, 1);
	var d4:String = str.substr(5, 100);
	
	
	if (d1 == (m + 1)) {
		
	
		array[d2 - 1].solarFestival = d4
		if (d3 == "*") {
				array[d2 - 1].color ="red"
			}
		}
	
	

		


}

//月周节日
for(i in wFtv) {
	
	
		
	
	
	/*
if(wFtv[i].match(/^(\d{2})(\d)(\d)([\s\*])(.+)$/))
if(Number(RegExp.$1)==(m+1)) {
tmp1=Number(RegExp.$2);
tmp2=Number(RegExp.$3);
if(tmp1<5)
array[((firstWeek>tmp2)?7:0) + 7*(tmp1-1) + tmp2 - firstWeek].solarFestival += RegExp.$5 + ' ';
else {
tmp1 -= 5;
tmp3 = (firstWeek+length-1)%7; //当月最后一天星期?
array[length - tmp3 - 7*tmp1 + tmp2 - (tmp2>tmp3?7:0) - 1 ].solarFestival += RegExp.$5 + ' ';
}
}*/

}


//农历节日
for(i in lFtv) {
	
	
	 str=lFtv[i]
	 d1 = Number(str.substr(0, 2));
	 d2 = Number(str.substr(2, 2));
	 d3 = str.substr(4, 1);
	 d4 = str.substr(5, 100);
	

	 
	


if(d1==(m+1)) {
 tmp1=Number(d1)-firstLM;
if(tmp1==-11) tmp1=1;
if(tmp1 >=0 && tmp1<n) {
tmp2 = lDPOS[tmp1] + Number(d2) -1;
if( tmp2 >= 0 && tmp2<length && array[tmp2].isLeap!=true) {
array[tmp2].lunarFestival += d4 + ' ';

if(d3=='*') array[tmp2].color = 'red';
}
}
}




}
/*
*/



//复活节只出现在3或4月
if(m==2 || m==3) {
var estDay:Object =  easter(y);
if(m == estDay.m)
array[estDay.d-1].solarFestival = array[estDay.d-1].solarFestival+' 复活节 Easter Sunday';
}


if(m==2) array[20].solarFestival = array[20].solarFestival//+unescape('%20%u6D35%u8CE2%u751F%u65E5');

//黑色星期五
if((firstWeek+12)%7==5)
array[12].solarFestival += '黑色星期五';

//今日
if(y == tY && m == tM) array[tD - 1].isToday = true;


return array
}

//======================================= 返回该年的复活节(春分后第一次满月周后的第一主日)
function easter(y):Object {
var obj:Object=new Object
var term2=sTerm(y,5); //取得春分日期
var dayTerm2 = new Date(Date.UTC(y,2,term2,0,0,0,0)); //取得春分的公历日期控件(春分一定出现在3月)
var lDayTerm2:Object =  Lunar(dayTerm2); //取得取得春分农历
var lMlen:Number
if(lDayTerm2.day<15) //取得下个月圆的相差天数
 lMlen= 15-lDayTerm2.day;
else
 lMlen= (lDayTerm2.isLeap? leapDays(y): monthDays(y,lDayTerm2.month)) - lDayTerm2.day + 15;

//一天等于 1000*60*60*24 = 86400000 毫秒
var l15 = new Date(dayTerm2.getTime() + 86400000*lMlen ); //求出第一次月圆为公历几日
var dayEaster = new Date(l15.getTime() + 86400000*( 7-l15.getUTCDay() ) ); //求出下个周日

obj.m = dayEaster.getUTCMonth();
obj.d = dayEaster.getUTCDate();

return obj
}

//====================== 中文日期
function cDay(d){
var s;

switch (d) {
case 10:
s = '初十'; break;
case 20:
s = '二十'; break;
break;
case 30:
s = '三十'; break;
break;
default :
s = nStr2[Math.floor(d/10)];
s += nStr1[d%10];
}
return(s);
}









function drawCld(SY,SM) {
var i,sD,s,size;
var cld:Array =  calendar(SY,SM);
var yDisplay:String
if(SY>1874 && SY<1909) yDisplay = '光绪' + (((SY-1874)==1)?'元':SY-1874);
if(SY>1908 && SY<1912) yDisplay = '宣统' + (((SY-1908)==1)?'元':SY-1908);
if(SY>1911) yDisplay = '建国' + (((SY-1949)==1)?'元':SY-1949);
var titles:String=""
titles = yDisplay +'年 农历 ' + cyclical(SY-1900+36) + '年 【'+Animals[(SY-4)%12]+'年】';
titletxt.text=titles
var YMBG:String = "  " + SY + "  " + monthName[SM];

yeartxt.text = "" + SY
monthtxt.text = "" + monthName[SM]

for(i=0;i<42;i++) {

//sObj=eval('SD'+ i);
//lObj=eval('LD'+ i);

var cell:CustomDailyCell = CellArray[i] as CustomDailyCell
//sObj.className = '';
var sObj:Object = new Object
var lObj:Object=new Object
sD = i - firstWeek;

if(sD > -1 && sD < cld.length) { //日期内

sObj.innerHTML = sD+1;

if(cld[sD].isToday) sObj.className = 'todyaColor'; //今日颜色

sObj.color = cld[sD].color; //法定假日颜色

if(cld[sD].lDay==1) //显示农历月
lObj.innerHTML = '<b>'+(cld[sD].isLeap?'闰':'') + cld[sD].lMonth + '月' + (monthDays(cld[sD].lYear,cld[sD].lMonth)==29?'小':'大')+'</b>';
else //显示农历日
lObj.innerHTML = cDay(cld[sD].lDay);

s=cld[sD].lunarFestival;
if(s.length>0) { //农历节日
if(s.length>6) s = s.substr(0, 4)+'...';
//s = s.fontcolor('red');
}
else { //公历节日
s=cld[sD].solarFestival;
if(s.length>0) {
size = (s.charCodeAt(0)>0 && s.charCodeAt(0)<128)?8:4;
if(s.length>size+2) s = s.substr(0, size)+'...';
//s=(s=='黑色星期五')?s.fontcolor('black'):s.fontcolor('blue');
}
else { //廿四节气
s=cld[sD].solarTerms;
//if(s.length>0) s = s.fontcolor('limegreen');
}
}

//if(cld[sD].solarTerms=='清明') s = '清明节'.fontcolor('red');
//if(cld[sD].solarTerms=='芒种') s = '芒种节'.fontcolor('red');
//if(cld[sD].solarTerms=='夏至') s = '夏至节'.fontcolor('red');
//if(cld[sD].solarTerms=='冬至') s = '冬至节'.fontcolor('red');


if(s.length > 0) {
	lObj.innerHTML = s;

	}
cell.OBJ = cld[sD] as Object

if(SelectedDate == cell.OBJ.sDay) {
	selectCell(cell)
	}
}
else { //非日期
sObj.innerHTML = '';
lObj.innerHTML = '';

cell.OBJ=null
}
}


SelectedYear = SY;
SelectedMonth = SM+1
//LoadDaily();
}


		

public function changeCld(e:*=null) {
var y,m;
y=yearlist.selectedIndex+1900;
m=monthlist.selectedIndex;
drawCld(y,m);
}
		
		
























/*




	public    function LoadDaily() {
		
			if (IsLoading) {
				Query=true
			
				return 
			}
		Query = false
		IsLoading = true
		//CustomLoading.Show()
			var loader:URLLoader = new URLLoader();
			SaveXMLconfigureListeners(loader);
			var url:String 
		
			url= GetDateURL + "&rnd=" + Math.random() + "&y=" + SelectedYear + "&m=" + SelectedMonth
			

			url=encodeURI(url)

			
			var request:URLRequest = new URLRequest(url);

			try {
				loader.load(request);
				
				
				//LoadingMC.visible=true;
			} catch (error:Error) {
				trace("Unable to load requested document.");
			}
			
		}

		private    function SaveXMLconfigureListeners(dispatcher:IEventDispatcher):void {
			dispatcher.addEventListener(Event.COMPLETE, SaveXMLcompleteHandler);
			dispatcher.addEventListener(Event.OPEN, SaveXMLopenHandler);
			dispatcher.addEventListener(ProgressEvent.PROGRESS, SaveXMLprogressHandler);
			dispatcher.addEventListener(SecurityErrorEvent.SECURITY_ERROR, SaveXMLsecurityErrorHandler);
			dispatcher.addEventListener(HTTPStatusEvent.HTTP_STATUS, SaveXMLhttpStatusHandler);
			dispatcher.addEventListener(IOErrorEvent.IO_ERROR, SaveXMLioErrorHandler);
		}

		private    function SaveXMLcompleteHandler(event:Event):void {
			
			
			
			return 
			IsLoading=false
			if (Query) {
				LoadDaily()
				return;
				}
			var loader:URLLoader = URLLoader(event.target);
			//LoadingMC.visible = false;
		//	trace(loader.data)
			
			try{
			var xml = new XML(loader.data)
			}catch (e:*) {
					//Alert.show("数据格式错误", null, null, 1);
					return 
				}
				
			if (xml.@error == "1") {
				//Alert.show(xml.@msg, null, null, 1);
				return 
			}			
		
			
			
			
			for (var i = 0; i < CellArray.length;i++ ){
			var cell:CustomDailyCell = CellArray[i] as CustomDailyCell
			SetDailyInfo(cell,xml)
			
			}
			
			
			
			
			
			
		
			
			
			
			//CustomLoading.Hide()

		}
	
		private function SetDailyInfo(cell:CustomDailyCell, xml:XML) {
			var obj:Object = cell.OBJ
			if(obj==null) return 
			var xmllist:XMLList = xml.node;
			var item:XML
			for each (item in xmllist) {
				var blogtime:String = item.@blogtime + ""
				var year=Number(blogtime.split("-")[0])
				var month=Number(blogtime.split("-")[1])
				var day = Number(blogtime.split("-")[2])
				
				if (obj.sYear == year && obj.sMonth == (month) && obj.sDay == day) {
					
					
					
					cell.SetDailyInfo(item.@ID,item.BlogContent)
					return 
					}
				}
			
			}
		
		
		private    function SaveXMLopenHandler(event:Event):void {
			//   trace("openHandler: " + event);
		}

		private    function SaveXMLprogressHandler(event:ProgressEvent):void {

		}

		private    function SaveXMLsecurityErrorHandler(event:SecurityErrorEvent):void {
			//LoadingMC.visible=false;
			IsLoading = false
			
			if (Query) {
				LoadDaily()
				return;
				}
				
		//	CustomLoading.Hide()
		}

		private    function SaveXMLhttpStatusHandler(event:HTTPStatusEvent):void {
			//  trace("httpStatusHandler: " + event);
		}

		private    function SaveXMLioErrorHandler(event:IOErrorEvent):void {
		//LoadingMC.visible=false;
		IsLoading=false
			if (Query) {
				LoadDaily()
				return;
				}
				
		//	CustomLoading.Hide()
		}
		
		
		
		
		
		
		
		*/
		
		
		
		
		
		
		
		
		
		  
	}
}