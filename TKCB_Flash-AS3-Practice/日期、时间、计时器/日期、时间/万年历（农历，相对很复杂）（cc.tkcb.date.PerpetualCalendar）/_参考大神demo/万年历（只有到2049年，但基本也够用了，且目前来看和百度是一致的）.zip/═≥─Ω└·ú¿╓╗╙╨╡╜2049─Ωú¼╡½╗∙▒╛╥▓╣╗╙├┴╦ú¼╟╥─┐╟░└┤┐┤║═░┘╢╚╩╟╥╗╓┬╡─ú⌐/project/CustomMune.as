﻿package  project{
	import flash.display.DisplayObject;
	import flash.display.DisplayObjectContainer;
	import flash.display.MovieClip
	import flash.events.ContextMenuEvent;
	import flash.events.MouseEvent
	import flash.events.Event;
	import flash.display.SimpleButton
	import flash.text.TextField
	import flash.events.MouseEvent
	
	
	
	import flash.ui.ContextMenu;
    import flash.ui.ContextMenuItem;
    import flash.ui.ContextMenuBuiltInItems;
    import flash.display.Sprite;
    import flash.text.TextField;


	
	/**
	
	flash右键菜单的管理类。
	给不同的显示对象设置不同的右键菜单
	*/
	
	public class CustomMune extends MovieClip{

		private static  var data:*
		private  static var CMArray:Array = new Array
		private  static var FArray:Array = new Array
		
	
		private static  var myContextMenu:ContextMenu;
		
		public  function  CustomMune() {
		
			
			
		}
			
			
       
		public static function  FindByDisplay(d:DisplayObjectContainer, label:String):int {
		
			for (var i:int = 0; i < CMArray.length; i++ ) {
				var cell:CustomMuneCell = CMArray[i] as CustomMuneCell;
				if (cell.Display == d&&cell.Label==label) {
					
					return i
					}
				
				}
				
				return -1
			
			}
			public  static function regest(d:DisplayObjectContainer, label:String, fun:Function = null, data:*= null) {
				Add(d, label, fun, data)
				
				
				}
		public  static function Add(d:DisplayObjectContainer, label:String,fun:Function=null,data:*=null) {
		var dd:Number=FindByDisplay(d,label)
		if (dd == -1) {
			CMArray.push(new CustomMuneCell(d,label,fun,data))
			
			
			}else {
				var cell:CustomMuneCell = CMArray[dd] as CustomMuneCell;
				cell.Display = d;
				cell.Label = label;
				cell.Func = fun;
				cell.Data = data
				}
			
			
			BuildMune(d)
			}

	
			
			
		
			private static function BuildMune(d:DisplayObjectContainer) {
				
				
				var 	myContextMenu :ContextMenu= new ContextMenu();
			myContextMenu.hideBuiltInItems();
			
			for (var i:int = 0; i < CMArray.length;i++ ){
			var cell:CustomMuneCell = CMArray[i] as CustomMuneCell;
				if (cell.Display == d) {
					
					
					var item:ContextMenuItem = new ContextMenuItem(cell.Label);
				
					item.addEventListener(ContextMenuEvent.MENU_ITEM_SELECT , cellfun);
					//trace(item.caption)
					
					myContextMenu.customItems.push(item);
					}
				
				}
				
				
			  
			
			d.contextMenu=myContextMenu
				
				}
      
				
				
			
		public static function  FindFunByDisplay(d:DisplayObjectContainer, label:String):CustomMuneCell {
		
			for (var i:int = 0; i < CMArray.length; i++ ) {
				var cell:CustomMuneCell = CMArray[i] as CustomMuneCell;
				if (cell.Display == d&&cell.Label==label) {
					
					return cell
					}
				
				}
				
				return null
			
			}
			
			
			
			
			
			
			
				
				private static  function cellfun(e:ContextMenuEvent) {
					
					var mc:DisplayObjectContainer = e.contextMenuOwner as DisplayObjectContainer
					var label:String=e.target.caption
					//trace(mc.name+"  "+label)
					
var cell:CustomMuneCell=FindFunByDisplay(mc, label);

			
					var fun:Function = 	cell.Func
					Data=cell.Data
					
					if (fun != null) {
						fun()
						}
		
		}
		
		public static function get Data():* { return data; }
		
		public static function set Data(value:*):void 
		{
			data = value;
		}
		
				
		}
	}
	
	
	
	