﻿package project{
	import flash.display.DisplayObject;
	import flash.display.MovieClip;
	import flash.text.TextField;
	import flash.events.TextEvent;
	import flash.events.*;

	import flash.text.TextFormat
	import flash.text.TextFormatAlign
	import flash.display.SimpleButton

	
	public class CustomButton extends MovieClip {
		private var  _txtfield:TextField
		private var _uptextfmt:TextFormat
		private var _overtxtfmt:TextFormat
		private var _disabletxtfmt:TextFormat
		private var disabled:Boolean=false
		private var _callback:Function
		public function CustomButton() {
		this.gotoAndStop(1)
		this.buttonMode = true
		this.mouseChildren=false
		this.addEventListener(MouseEvent.MOUSE_OVER,mouseover)
		this.addEventListener(MouseEvent.MOUSE_OUT,mouseout)
		this.addEventListener(MouseEvent.MOUSE_DOWN,mousedown)
		this.addEventListener(MouseEvent.MOUSE_UP,mouseover)
		this.addEventListener(MouseEvent.CLICK,mouseclick)
		
		
			uptextfmt = new TextFormat
			uptextfmt.size = 12;
			uptextfmt.color = 0x000000;
			uptextfmt.align=TextFormatAlign.CENTER
			overtxtfmt = new TextFormat;
			overtxtfmt.size = 12;
			overtxtfmt.color = 0x000000;
			
			overtxtfmt.align=TextFormatAlign.CENTER
			disabletxtfmt = new TextFormat
			disabletxtfmt.color = 0xcccccc
			disabletxtfmt.size = 12;
				disabletxtfmt.align=TextFormatAlign.CENTER
				}
				
			public function mouseclick(e:MouseEvent){
				
				if(CallBack!=null){
					CallBack()
					}
				}
				public function mouseover(e:MouseEvent) {
					
					if (_txtfield != null) {
						_txtfield.setTextFormat(overtxtfmt)
						}
					this.gotoAndStop(2);
					
					}
		
			public function mouseout(e:MouseEvent) {
							if (_txtfield != null) {
						_txtfield.setTextFormat(uptextfmt)
						}
					this.gotoAndStop(1);
					
					}
					
			public function mousedown(e:MouseEvent) {
					if (_txtfield != null) {
						_txtfield.setTextFormat(overtxtfmt)
						}
					this.gotoAndStop(3);
					
					}
							
							
							
							
							public function set label(value:String) {
						
							
							Label=value
							}
							
							public function get Label():String {
						if (_txtfield != null) {
							return _txtfield.text
							}
							
							return  null
							}
							
							
							public function get label():String {
							return Label
							}
							
							
							
					public function set Label(value:String) {
						
						
						if (_txtfield == null) {
							
							var h:Number = 18
							h=h<this.height?h:this.height
							_txtfield = new TextField
							_txtfield.width = this.width
							_txtfield.height = h
							_txtfield.selectable = false
							_txtfield.mouseEnabled = false							
							_txtfield.y=(this.height-h)/2-1
							addChild(_txtfield)
							
							}

						
							_txtfield.text = value;
							_txtfield.setTextFormat(uptextfmt)
						}		
						
						public function get Disabled():Boolean { return disabled; }
						
						public function set Disabled(value:Boolean):void 
						{
							
							disabled = value;
							
							if (disabled) {
								
									if (_txtfield != null) {
						_txtfield.setTextFormat(disabletxtfmt)
						
					
						
						}
							this.gotoAndStop(4)
						this.mouseEnabled=false
								
								}else {
									
									if (_txtfield != null) {
						_txtfield.setTextFormat(uptextfmt)
						
						}
						this.gotoAndStop(1)
						this.mouseEnabled=true
									
									}
							
							
						}
						
						public function get uptextfmt():TextFormat { return _uptextfmt; }
						
						public function set uptextfmt(value:TextFormat):void 
						{
							_uptextfmt = value;
						}
						
						public function get overtxtfmt():TextFormat { return _overtxtfmt; }
						
						public function set overtxtfmt(value:TextFormat):void 
						{
							_overtxtfmt = value;
						}
						
						public function get disabletxtfmt():TextFormat { return _disabletxtfmt; }
						
						public function set disabletxtfmt(value:TextFormat):void 
						{
							_disabletxtfmt = value;
						}
						
						public function get CallBack():Function { return _callback; }
						
						public function set CallBack(value:Function):void 
						{
							_callback = value;
						}
						
						
					
	}
}