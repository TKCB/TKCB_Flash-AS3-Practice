﻿package  project{
	import flash.display.DisplayObjectContainer;

	
	
	
	
	public class CustomMuneCell{

		private    var label:String=""
		private   var func:Function
		private   var display:DisplayObjectContainer
		
		private var  data:*
		
		public  function  CustomMuneCell(display:DisplayObjectContainer,label:String,fun:Function,data:*=null) {
		Display = display
		Label = label
		Func = fun;
			Data=data
		}
		
		public function get Label():String { return label; }
		
		public function set Label(value:String):void 
		{
			label = value;
		}
		
		public function get Func():Function { return func; }
		
		public function set Func(value:Function):void 
		{
			func = value;
		}
		
		public function get Display():DisplayObjectContainer { return display; }
		
		public function set Display(value:DisplayObjectContainer):void 
		{
			display = value;
		}
		
		public function get Data():* { return data; }
		
		public function set Data(value:*):void 
		{
			data = value;
		}
			
			
       

	
		
		
		
		
		
		
		
		
				
		}
	}
	
	
	
	