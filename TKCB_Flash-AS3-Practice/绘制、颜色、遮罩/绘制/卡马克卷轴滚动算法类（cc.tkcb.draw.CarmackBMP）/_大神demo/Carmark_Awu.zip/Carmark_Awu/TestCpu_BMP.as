package  
{
	import flash.geom.Rectangle;
	import flash.display.Bitmap;
	import flash.display.StageScaleMode;
	import flash.display.BitmapData;
	import flash.events.Event;
	import flash.net.URLRequest;
	import flash.display.Loader;
	import flash.display.Sprite;

	/**
	 * @author Administrator
	 */
	public class TestCpu_BMP extends Sprite
	{

		public function TestCpu_BMP(): void
		{ 
			stage.scaleMode = StageScaleMode.NO_SCALE;
			var loader: Loader = new Loader();
			loader.load(new URLRequest("touhou.jpg" ) );
			
			loader.contentLoaderInfo.addEventListener(Event.COMPLETE, onLoaded );
		}

		private function onLoaded(e: Event): void
		{
			var bmd: BitmapData = BitmapData(e.target.content.bitmapData );
			trace("bitmapdata loaded : " + bmd .width + "," + bmd .height );
			var bmp: Bitmap = new Bitmap(bmd );
			addChild(bmp );
			//bmp.cacheAsBitmap=true;
    
			this.addEventListener(Event.ENTER_FRAME, onEnterFrame );
			var i: int = 0;
			
			function onEnterFrame(e: Event): void
			{ 
				bmp.x--;
			}
		}
	}
}
