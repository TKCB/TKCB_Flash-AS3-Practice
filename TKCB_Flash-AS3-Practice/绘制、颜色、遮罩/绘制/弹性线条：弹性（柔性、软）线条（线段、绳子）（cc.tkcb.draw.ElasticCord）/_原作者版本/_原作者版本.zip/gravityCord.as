﻿package {
	import flash.display.Sprite
	import flash.geom.Point
	import flash.events.*
	class ElasticCord extends Sprite {
		private var _g: Number
		private var _gravity: Number
		private var _elasticity: Number
		private var _friction: Number
		private var _segments: uint

		private var _startPointObj: Object = new Object()
			private var _endPointObj: Object = new Object()
			public function ElasticCord($startPoint: Point, $endPoint: Point, $segments: uint = 8, $gravity: Number = 9.8, $elasticity: Number = .2, $friction: Number = .8) {

				_gravity = $gravity
				_elasticity = $elasticity
				_friction = $friction
				_segments = $segments > 1 ? $segments : 1

				_g = _gravity / (_segments * 2)
				startPoint = $startPoint
				endPoint = $endPoint

				initCord()
				this.addEventListener(Event.ENTER_FRAME, drawCord)
			}
		public function set startPoint(value: Point): void {
			_startPointObj.x = value.x
			_startPointObj.y = value.y
		}
		public function get startPoint(): Point {
			return new Point(_startPointObj.x, _startPointObj.y)
		}
		public function set endPoint(value: Point): void {
			_endPointObj.x = value.x
			_endPointObj.y = value.y
		}
		public function get endPoint(): Point {
			return new Point(_endPointObj.x, _endPointObj.y)
		}
		public function set segments(value: uint): void {
			_segments = value
		}
		private function initCord(): void {

			var tempSegments: int = _segments
			var dis: Number = Point.distance(startPoint, endPoint)
			var step: Number = dis / tempSegments
			var tempPointObj: Object = _startPointObj

			while (tempSegments >= 0) {
				var f: Number = step * tempSegments / dis
				var pointObj = addPoint(tempPointObj, Point.interpolate(startPoint, endPoint, f))
				tempPointObj.nextPoint = pointObj
				tempPointObj = pointObj
				tempSegments--
			}
			tempPointObj.nextPoint = _endPointObj
		}
		private function addPoint(prevPoint: Object, ownPoint: Point): Object {
			var pointObj: Object = new Object()
			pointObj.prevPoint = prevPoint
			pointObj.x = ownPoint.x
			pointObj.y = ownPoint.y
			pointObj.vx = 0
			pointObj.vy = 0
			return pointObj
		}
		private function drawCord(e: Event = null): void {

			this.graphics.clear()
			this.graphics.lineStyle(1, 0)
			this.graphics.moveTo(_startPointObj.x, _startPointObj.y)


			for (var tempPointObj = _startPointObj.nextPoint; tempPointObj.nextPoint; tempPointObj = tempPointObj.nextPoint) {
				var tempx: Number = (tempPointObj.prevPoint.x + tempPointObj.nextPoint.x) / 2
				var tempy: Number = (tempPointObj.prevPoint.y + tempPointObj.nextPoint.y) / 2
				tempPointObj.vx += (tempx - tempPointObj.x) * _elasticity
				tempPointObj.vy += (tempy - tempPointObj.y) * _elasticity + _g
				tempPointObj.vx *= _friction
				tempPointObj.vy *= _friction
				tempPointObj.x += tempPointObj.vx
				tempPointObj.y += tempPointObj.vy
			}

			for (tempPointObj = _startPointObj.nextPoint; tempPointObj.nextPoint; tempPointObj = tempPointObj.nextPoint) {
				this.graphics.curveTo(tempPointObj.x, tempPointObj.y, (tempPointObj.nextPoint.x + tempPointObj.x) / 2, (tempPointObj.nextPoint.y + tempPointObj.y) / 2);
			}

			this.graphics.lineTo(tempPointObj.x, tempPointObj.y);
		}
	}
}