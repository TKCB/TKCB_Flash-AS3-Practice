﻿package  {
	import flash.utils.ByteArray;	
	public class ReadText {
		private var mydata:ByteArray;
		private var _text:String;
		private var reg:RegExp=/\r/g;
		public function ReadText(textData:ByteArray) {
			// constructor code
			this.mydata=textData;
			var type:String=getFileType(this.mydata);			
			var changdu:uint=this.mydata.length;
			this._text="";
			switch(type){
				case "ANSI" :			   
				this.mydata.position=0;
			    this._text =this.mydata.readMultiByte((changdu - this.mydata.position),"gb2312");				
			    break;
		        case "Unicode" :
		        case "Unicode big endian" :
		        case "UTF-8" :
			    this._text = this.mydata.toString();
			    break;
			}
			this._text = this._text.replace(reg,"");		
		}
		public function get Text():String
		{
			return this._text;
		}//读取文本
		private function getFileType(fileData:ByteArray):String
		{
			if(fileData.length<2)
			{
				if(fileData.length==1){
					if(fileData[0]<(0x80)){
						return "UTF-8";
					}else{
						return "ANSI";
					}
				}
				if(fileData.length==0){
					return "ANSI";
				}
			}
		
	          var b0:int = fileData.readUnsignedByte();
	          var b1:int = fileData.readUnsignedByte();			  
	          var fileType:String = "ANSI";
	          if (((b0 == 0xFF) && b1 == 0xFE))
	          {
		           fileType = "Unicode";
	          }
	          else if (((b0 == 0xFE) && b1 == 0xFF))
	          {
		           fileType = "Unicode big endian";
	          }
	          else if (((b0 == 0xEF) && b1 == 0xBB))
	          {
		          fileType = "UTF-8";
	          }
			  if(fileType=="ANSI"){
				  fileType=NO_bom_UTF(fileData)?"UTF-8":"ANSI";
			  }
	          return fileType;
        }//跟据格式标签来判断格式
		private function NO_bom_UTF(bit:ByteArray):Boolean
		{
			var panduan:Boolean=true;			
			var weizhi:int=0;			
			while(weizhi<bit.length)
			{
				if(bit[weizhi]<(0x80)){// (10000000): 值小于0x80的为ASCII字符
					weizhi++;
				}else if(bit[weizhi]<(0xC0)){// (11000000): 值介于0x80与0xC0之间的为无效UTF-8字符 
					panduan=false;
					break;
				}else if(bit[weizhi]<(0xE0)){// (11100000): 此范围内为2字节UTF-8字符
				    if(weizhi>=bit.length-1){
						break;
					}
					if((bit[weizhi+1]<(0x80))||(bit[weizhi+1]>=(0xC0))){
						panduan=false;
						break;
					}					
					weizhi+=2;
				}else if(bit[weizhi]<(0xF0)){// (11110000): 此范围内为3字节UTF-8字符
				    if(weizhi>=bit.length-2){
						break;
					}
					if((bit[weizhi+1]<(0x80))||(bit[weizhi+1]>=(0xC0))){
						panduan=false;
						break;
					}
					if((bit[weizhi+2]<(0x80))||(bit[weizhi+2]>=(0xC0))){
						panduan=false;
						break;
					}					
					weizhi+=3;
				}else{
					panduan=false;
					break;
				}
			}
			return panduan;
		}//如果是无BOM头的UTF-8判断是否是UTF—8		
	}
	
}
//读取外部text文件