package  
{
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Sprite;
	import flash.geom.Point;
	
	/**
	 * ...
	 * @author 星雪火
	 */
	public class Chip extends Sprite 
	{
		private var po:Vector.<Point> ;		
		private var bpd:BitmapData;
		
		public function Chip(bitmapdata:BitmapData) {
			this.bpd = bitmapdata;
			this.mouseChildren = false;
		}
		
		public function setPoint(value:Vector.<Point>):void {
			var len:int = value.length - 1;
			
			this.po = value;
			this.graphics.clear();
			this.graphics.beginBitmapFill(bpd);
			this.graphics.lineStyle(1, 0x000000);
			this.graphics.moveTo(po[len].x, po[len].y);
			
			for (var i:int = 0; i < po.length; i++) {		
				this.graphics.lineTo(po[i].x, po[i].y);
			}
			
			this.graphics.endFill();			
		}
		
		public function get PO():Vector.<Point> {
			return po;
		}
		
	}

}