package  
{
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.MovieClip;
	import flash.display.Shape;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.geom.Point;
	
	/**
	 * ...
	 * @author 星雪火
	 */
	public class Cutter extends MovieClip 
	{
		private var image:Array = new Array;//碎片集合
		private var bitmapdata:BitmapData;//图片数据
		private var maxw:int = 300;
		private var maxh:int = 400;
		
		private var linebox:Shape;//切线容器
		private var starPoint:Point;//切线起始点
		private var endPoint:Point;//切线终止点
		
		public function Cutter() 
		{
			stage?init(null):this.addEventListener(Event.ADDED_TO_STAGE, init);
		}
		private function init(evt:Event=null):void{
			bitmapdata = new BitmapData(maxw, maxh);
			bitmapdata.perlinNoise(150, 150, 2, int.MAX_VALUE*Math.random(), false, true);
			
			var po:Vector.<Point> = new Vector.<Point>;//第一个图形顶点
			po.push(new Point(maxw, 0), new Point(maxw, maxh), new Point(0, maxh), new Point(0, 0));
			var chip:Chip = new Chip(bitmapdata);
			chip.setPoint(po);//将顶点坐标传参给chip对象，并在顶点范围生成图像
			addChild(chip);
			chip.x = 20;
			chip.y = 20;
			
			image.push(chip);
			
			linebox = new Shape;
			addChild(linebox);
			stage.addEventListener(MouseEvent.MOUSE_DOWN, onMouseDown);

		}
		
		private function onMouseDown(evt:MouseEvent):void {
			var obj:Object = evt.target;
			//鼠标按下时，若鼠标点到的是Chip碎片，则移动此碎片，否则开始画线
			if(obj is Chip){
				var chip:Chip = evt.target as Chip;
				this.setChildIndex(chip, this.getChildIndex(linebox)-1);
				chip.startDrag();
				stage.addEventListener(MouseEvent.MOUSE_UP, function(evt:MouseEvent):void {
					evt.currentTarget.removeEventListener(evt.type, arguments.callee);
					chip.stopDrag();
					});
			}else {
				starPoint = new Point(this.mouseX, this.mouseY);			
			
				stage.addEventListener(MouseEvent.MOUSE_MOVE, onMouseMove);
				stage.addEventListener(MouseEvent.MOUSE_UP, onMouseUp);
			}
		}
		
		/**
		 * 画线
		 */
		private function onMouseMove(evt:MouseEvent):void {
			endPoint = new Point(this.mouseX, this.mouseY);
			
			linebox.graphics.clear();
			linebox.graphics.lineStyle(1,0xFF0000);
			
			linebox.graphics.moveTo(starPoint.x, starPoint.y);
			linebox.graphics.lineTo(endPoint.x, endPoint.y);
		}
		
		private function onMouseUp(evt:MouseEvent):void {
			//完成画线
			stage.removeEventListener(MouseEvent.MOUSE_MOVE, onMouseMove);
			stage.removeEventListener(MouseEvent.MOUSE_UP, onMouseUp);
			
			linebox.graphics.endFill();
			
			var imagen:Array = new Array;//将切割出的碎片放入这里
			for (var i:int = 0; i < image.length; i++) {
				var chip:Chip = image[i];
				var chipn:Chip = imageCutter(chip, starPoint, endPoint);
				if (chipn) {
					imagen.push(chipn);
				}
			}
			
			//将切割出的碎片重新放回image
			for (var k:int = 0; k < imagen.length; k++) {
				image.push(imagen[k]);
			}
			linebox.graphics.clear();
		}
		/**
		 * 将碎片与切线进行处理，若可以切割，则将碎片分割成两部分，一部分用于对传入的chip重新赋值，另一部分生成新的chip作为返回值
		 * @param	chip	
		 * @param	st	切线起始点
		 * @param	en	切线终止点
		 * @return
		 */
		private function imageCutter(chip:Chip, st:Point, en:Point):Chip{
			
			//若图形可以被切割，则会生成两个图形的顶点，分别存入arr1和arr2
			var arr1:Vector.<Point> = new Vector.<Point>;
			var arr2:Vector.<Point> = new Vector.<Point>;
			var po:Vector.<Point> = chip.PO;
			var tx:Number = chip.x;
			var ty:Number = chip.y;
			
			var num:int = 0;//计算交点数量
			
			for (var i:int = 0; i < po.length; i++) {
				var n:int = (i + 1) % po.length;
				var lm:Point = new Point(po[i].x, po[i].y );
				var ln:Point = new Point(po[n].x, po[n].y );
				var ls:Point = new Point(st.x - tx, st.y - ty);
				var le:Point = new Point(en.x - tx, en.y - ty);
				
				var pp:Point = intersection(lm, ln, ls, le);//计算两条线段交点
				
				if (num != 1) {
					arr1.push(lm);
				}else {
					arr2.push(lm);
				}
				if (pp != null) {
					arr1.push(pp);
					arr2.push(pp);
					num++;
				}
			}
			
			var chipn:Chip = null;
			if (num == 2) {
				chip.setPoint(arr1);
				chipn = new Chip(bitmapdata);
				chipn.setPoint(arr2);
				chipn.x = chip.x;
				chipn.y = chip.y;
				addChildAt(chipn, this.getChildIndex(chip));
			}
			
			return chipn;
		}
		

			
		/**
		 * 计算两条线段的交点，若没有则返回null
		 */
		private function intersection(u1:Point, u2:Point, v1:Point, v2:Point):Point {
			//判断是否平行
			var d:Number = (u2.y - u1.y) * (v2.x - v1.x) - (v2.y - v1.y) * (u2.x - u1.x);
			
			if (d == 0) {
				return null;
			}
			
			//计算交点
			var px:Number = ((u2.x - u1.x) * (v2.x - v1.x) * (v1.y - u1.y) + (u2.y - u1.y) * (v2.x - v1.x) * u1.x - (v2.y - v1.y) * (u2.x - u1.x) * v1.x) / d;
			var py:Number = ((u2.y - u1.y) * (v2.y - v1.y) * (v1.x - u1.x) + (u2.x - u1.x) * (v2.y - v1.y) * u1.y - (v2.x - v1.x) * (u2.y - u1.y) * v1.y) / ( -d);
			
			//判断交点是否在线段上
			var k1:Number = (px - u1.x) * (px - u2.x);
			var k2:Number = (px - v1.x) * (px - v2.x);
			var k3:Number = (py - u1.y) * (py - u2.y);
			var k4:Number = (py - v1.y) * (py - v2.y);
			
			
			if (k1<=0 && k2 <=0  && k3 <=0 && k4 <=0 ) {
				return new Point(px,py);				
			}else {
				return null;
			}
			
		}
		
		
		
		
			
		
	}

}