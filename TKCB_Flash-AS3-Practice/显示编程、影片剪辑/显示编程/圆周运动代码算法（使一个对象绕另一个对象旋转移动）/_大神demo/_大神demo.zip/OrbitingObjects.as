﻿package{
	import flash.display.*;
	import flash.events.*;
	
	public class OrbitingObjects extends MovieClip{
		public var orbiter:Orbiter = new Orbiter(); // The MovieClip That Orbits
		public var origin:Origin = new Origin(); // The MovieClip That Is Orbited
		public var cDirect:CDirect = new CDirect(); // The MovieClip That Changes Orbit Direction
		public var pSpeed:PSpeed = new PSpeed(); // The MovieClip That Increases Orbit Speed
		public var mSpeed:MSpeed = new MSpeed(); // The MovieClip That Decreases Orbit Speed
		public var navPad:NavPad = new NavPad(); // The MovieClip That Navigates The Origin
		public var angle:Number = 0; // The Initial Angle Orbiting Starts From
		public var speed:Number = 3; // Number Of Pixels Orbited Per Frame
		public var radius:Number = 75; // Orbiting Distance From Origin
		public var orbitDirection:String = "clockwise"; // Orbit Direction
		public var moveDirection:String = "none";
		public function OrbitingObjects(){
			addChild(orbiter);
			addChild(origin);
			origin.x = stage.stageWidth/2;
			origin.y = stage.stageHeight/2;
			addChild(cDirect);
			cDirect.name = "cDirect";
			cDirect.x = stage.stageWidth/2;
			cDirect.y = 325;
			addChild(pSpeed);
			pSpeed.name = "pSpeed";
			pSpeed.x = 320;
			pSpeed.y = 325;
			addChild(mSpeed);
			mSpeed.name = "mSpeed";
			mSpeed.x = 270;
			mSpeed.y = 325;
			addChild(navPad);
			navPad.x = 75;
			navPad.y = 325;
			navPad.addEventListener(MouseEvent.MOUSE_DOWN, navPadDown);
			navPad.addEventListener(MouseEvent.MOUSE_UP, navPadUp);
			addEventListener(MouseEvent.CLICK, directionChanges);
			addEventListener(Event.ENTER_FRAME, enterFrame);
		}
		public function navPadDown(event:MouseEvent):void{
			moveDirection = event.target.name;
		}
		public function navPadUp(event:MouseEvent):void{
			moveDirection = "none";
		}
		public function directionChanges(event:MouseEvent):void{
			switch(event.target.name){
				case "cDirect":
					if(orbitDirection == "clockwise"){
						orbitDirection = "counterclockwise";
					}else{
						orbitDirection = "clockwise";
					}
				break;
				case "pSpeed":
					if(speed<10){
						speed+=1;
					}
				break;
				case "mSpeed":
					if(speed>-10){
						speed-=1;
					}
				break;
			}
		}
		public function enterFrame(event:Event):void{
			//Orbiting The Origin
			var rad:Number = angle * (Math.PI / 180); // Converting Degrees To Radians
			orbiter.x = (origin.x + radius * Math.cos(rad))-75;
			orbiter.y = origin.y + radius * Math.sin(rad);
			// Changing Orbit Direction
			if(orbitDirection == "clockwise"){
				angle+=speed;
			}else{
				angle-=speed;
			}
			//Rotating The Orbiter To Continuously Face The Origin
			orbiter.rotation=(Math.atan2(orbiter.y-origin.y, orbiter.x-(origin.x-25)) * 180 / Math.PI);
			//Move The Origin
			switch(moveDirection){
					case "up":
						if(origin.y>100){
							origin.y-=2;
						}
					break;
					case "down":
						if(origin.y<250){
							origin.y+=2;
						}
					break;
					case "left":
						if(origin.x>100){
							origin.x-=2;
						}
					break;
					case "right":
						if(origin.x<250){
							origin.x+=2;
						}
					break;
				}
		}
	}
}