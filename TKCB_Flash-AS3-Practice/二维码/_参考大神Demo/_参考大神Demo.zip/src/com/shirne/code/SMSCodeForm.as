package com.shirne.code 
{
	import fl.controls.Button;
	import fl.controls.TextArea;
	import fl.controls.TextInput;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.net.navigateToURL;
	import flash.net.URLRequest;
	/**
	 * ...
	 * @author Shirne
	 */
	public class SMSCodeForm extends CodeForm 
	{
		private var tel:TextInput;
		private var content:TextArea;
		
		public function SMSCodeForm() 
		{
			super();
			_content.Text = "";
		}
		
		//smsto:13631129077:短信内容
		public override function isMatch(cont:String):Boolean {
			if (/^(s|m)msto:/i.test(cont)) {
				return true;
			}
			return false;
		}
		
		public override function showForm(e:Event):void {
			var labelWidth:int = 40;
			var contWidth:int = 480 - labelWidth-10;
			
			addChild(createLabel('号码', 0, 10, labelWidth));
			tel = createInput(labelWidth+10, 10, contWidth);
			addChild(tel);
			
			addChild(createLabel('内容', 0, 40, labelWidth));
			content = createTextArea(labelWidth+10, 40, contWidth);
			addChild(content);
			
		}
		
		public override function unserialize(cont:String):void {
			var str:String = cont.substr("smsto:".length);
			var carr:Array = str.split(':');
			tel.text = carr[0];
			content.text = carr[1] || "";
		}
		
		public override function serialize():String {
			return "smsto:" + tel.text + ":" + content.text;
		}
		
	}

}