package com.shirne.code 
{
	import fl.controls.Label;
	import fl.controls.TextArea;
	import fl.controls.TextInput;
	import flash.events.Event;
	/**
	 * ...
	 * @author Shirne
	 */
	public class CardCodeForm extends CodeForm 
	{
		private var fn:TextInput;
		private var mobile:TextInput;
		private var workphone:TextInput;
		private var fax:TextInput;
		private var email:TextInput;
		private var url:TextInput;
		private var org:TextInput;
		private var role:TextInput;
		private var title:TextInput;
		private var addr:TextInput;
		private var post:TextInput;
		private var note:TextArea;
		
		public function CardCodeForm() 
		{
			super();
			_content.Text = "";
		}
		
		/**
		 * @param	e
		 */
		public override function showForm(e:Event):void {
			var line:int = 0;
			var lineHeight:int = 28;
			var labelWidth:int = 40;
			var sWidth:int = 480;
			
			var posLeft:int = labelWidth + 10;
			var posRight:int = labelWidth + 10 + sWidth * .5;
			var halftWidth:int = sWidth * .5 - labelWidth - 20;
			
			addChild(createLabel('姓名',0,line*lineHeight,labelWidth));
			fn = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(fn);
			
			addChild(createLabel('手机',sWidth*.5,line*lineHeight,labelWidth));
			mobile = createInput(posRight, line * lineHeight, halftWidth);
			addChild(mobile);
			
			line++;
			
			addChild(createLabel('邮箱',0,line*lineHeight,labelWidth));
			email = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(email);
			
			addChild(createLabel('主页',sWidth*.5,line*lineHeight,labelWidth));
			url = createInput(posRight, line * lineHeight, halftWidth);
			url.text = "http://";
			addChild(url);
			
			line++;
			
			addChild(createLabel('公司',0,line*lineHeight,labelWidth));
			org = createInput(posLeft, line * lineHeight, sWidth-labelWidth-20);
			addChild(org);
			
			line++;
			
			addChild(createLabel('职称',0,line*lineHeight,labelWidth));
			role = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(role);
			
			addChild(createLabel('职位',sWidth*.5,line*lineHeight,labelWidth));
			title = createInput(posRight, line * lineHeight, halftWidth);
			addChild(title);
			
			line++;
			
			addChild(createLabel('电话',0,line*lineHeight,labelWidth));
			workphone = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(workphone);
			
			addChild(createLabel('传真',sWidth*.5,line*lineHeight,labelWidth));
			fax = createInput(posRight, line * lineHeight, halftWidth);
			addChild(fax);
			
			line++;
			
			addChild(createLabel('地址',0,line*lineHeight,labelWidth));
			addr = createInput(posLeft, line * lineHeight, halftWidth+100);
			addChild(addr);
			
			addChild(createLabel('邮编',sWidth*.5+100,line*lineHeight,labelWidth));
			post = createInput(posRight+100, line * lineHeight, halftWidth-100);
			addChild(post);
			
			line++;
			
			addChild(createLabel('备注',0,line*lineHeight,labelWidth));
			note = new TextArea();
			note.width = sWidth;
			note.height = 50;
			note.y = line * lineHeight;
			note.text = "备注";
			note.addEventListener(Event.CHANGE, function():void {
				_content.Text = serialize();
			});
			addChild(note);
		}
		
		public override function isMatch(cont:String):Boolean {
			if (cont.indexOf('BEGIN:VCARD')==0) {
				return true;
			}
			return false;
		}
		
		public override function unserialize(val:String):void {
			var vCard:Object = new Object();
			var arrs:Array = val.split("\n");
			var line:String;
			var mPos:int = -1;
			for (var i:int = 0; i < arrs.length; i++ ) {
				line = String(arrs[i]).replace(/^\s*|\s*$/g, '');
				mPos = line.indexOf(':');
				if (mPos > 0) {
					switch(line.substr(0,mPos).toUpperCase()) {
						case "FN":
						case "N":
							vCard.fn = line.substr(mPos+1);
							break;
						case "TEL;CELL":
						case "TEL;CELL;VOICE":
							vCard.mobile = line.substr(mPos+1);
							break;
						case "TEL":
						case "TEL;WORK;VOICE":
							vCard.workphone = line.substr(mPos+1);
							break;
						case "TEL;WORK;FAX":
							vCard.fax = line.substr(mPos+1);
							break;
						case "EMAIL":
						case "EMAIL;PREF;INTERNET":
							vCard.email = line.substr(mPos+1);
							break;
						case "URL":
							vCard.url = line.substr(mPos+1);
							break;
						case "ORG":
							vCard.org = line.substr(mPos+1);
							break;
						case "ROLE":
							vCard.role = line.substr(mPos+1);
							break;
						case "TITLE":
						case "TIL":
							vCard.title = line.substr(mPos+1);
							break;
						case "ADR":
						case "ADR;WORK;POSTAL":
							var address:Array = line.substr(mPos+1).split(';');
							vCard.addr = address[0];
							vCard.post = address[1] || "";
							break;
						case "NOTE":
							vCard.note = line.substr(mPos+1);
							break;
					}
				}
			}
			
			fn.text = vCard.fn || "";
			mobile.text = vCard.mobile || "";
			workphone.text = vCard.workphone || "";
			fax.text = vCard.fax || "";
			email.text = vCard.email || "";
			url.text = vCard.url || "";
			org.text = vCard.org || "";
			role.text = vCard.role || "";
			title.text = vCard.title || "";
			addr.text = vCard.addr || "";
			post.text = vCard.post || "";
			note.text = vCard.note || "";
		}
		
		/**
		 * BEGIN:VCARD
		 * VERSION:3.0
		 * FN:任侠
		 * TEL;CELL;VOICE:15201280000
		 * TEL;WORK;VOICE:010-62100000
		 * TEL;WORK;FAX:010-62100001
		 * EMAIL;PREF;INTERNET:lzw#lzw.me
		 * URL:http://lzw.me
		 * ORG:志文工作室
		 * ROLE:产品部
		 * TITLE:CTO
		 * ADR;WORK;POSTAL:北京市朝阳区北四环中路35号;100101
		 * REV:2012-12-27T08:30:02Z
		 * END:VCARD
		 * 
		 * BEGIN:VCARD
		 * VERSION:3.0
		 * N:name
		 * EMAIL:email
		 * TEL:telephone
		 * TEL;CELL:mobile
		 * ADR:adddress
		 * ORG:comp
		 * TITLE:job
		 * URL:home
		 * NOTE:memo
		 * END:VCARD
		 */
		public override function serialize():String {
			var str:Array=new Array();
			
			str.push("BEGIN:VCARD");
			str.push("VERSION:3.0");
			str.push("N:" + fn.text);
			if(mobile.text)str.push("TEL;CELL:" + mobile.text);
			if(workphone.text)str.push("TEL:" + workphone.text);
			if(fax.text)str.push("TEL;WORK;FAX:" + fax.text);
			if(email.text)str.push("EMAIL:" + email.text);
			if(url.text)str.push("URL:" + url.text);
			if(org.text)str.push("ORG:" + org.text);
			if(role.text)str.push("ROLE:" + role.text);
			if(title.text)str.push("TITLE:" + title.text);
			if (addr.text) str.push("ADR:" + addr.text + ";" + post.text);
			if (note.text) str.push("NOTE:" + title.text);
			str.push("REV:" + new Date().toLocaleString());
			str.push("END:VCARD");
			
			
			return str.join("\n");
		}
	}

}