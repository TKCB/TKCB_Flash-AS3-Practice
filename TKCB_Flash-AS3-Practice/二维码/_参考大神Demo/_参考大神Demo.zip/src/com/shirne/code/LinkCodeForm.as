package com.shirne.code 
{
	import fl.controls.Button;
	import fl.controls.TextInput;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.net.navigateToURL;
	import flash.net.URLRequest;
	/**
	 * ...
	 * @author Shirne
	 */
	public class LinkCodeForm extends CodeForm 
	{
		private var link:TextInput;
		private var btn:Button;
		
		public function LinkCodeForm() 
		{
			super();
			_content.Text = "http://";
		}
		
		public override function isMatch(cont:String):Boolean {
			if (/^(https?|ftp|sms|tel|mailto):/i.test(cont)) {
				return true;
			}
			return false;
		}
		
		public override function showForm(e:Event):void {
			link = new TextInput();
			link.y = 20;
			link.width = 480;
			link.text = _content.Text;
			link.addEventListener(Event.CHANGE, function(e:Event):void {
				_content.Text = link.text;
				checkUrl(_content.Text);
			});
			addChild(link);
			btn = new Button();
			btn.y = 50;
			btn.visible = false;
			btn.label = "打开链接";
			btn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
				navigateToURL(new URLRequest(_content.Text));
			});
			addChild(btn);
		}
		
		public override function unserialize(cont:String):void {
			link.text = cont;
			checkUrl(cont);
		}
		
		public override function serialize():String {
			return link.text;
		}
		
		private function checkUrl(url:String):void {
			if(url.match(/^https?:\/\/([\w\d\-]+\.[\w\d]+)+/)){
				btn.visible = true;
			}else {
				btn.visible = false;
			}
		}
		
	}

}