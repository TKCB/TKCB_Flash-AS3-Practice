package com.shirne.code 
{
	import fl.controls.Button;
	import fl.controls.ComboBox;
	import fl.controls.TextInput;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.net.navigateToURL;
	import flash.net.URLRequest;
	/**
	 * ...
	 * @author Shirne
	 */
	public class WIFICodeForm extends CodeForm 
	{
		private var network:TextInput;
		private var passtype:ComboBox;
		private var password:TextInput;
		
		public function WIFICodeForm() 
		{
			super();
			_content.Text = "";
		}
		
		//WIFI:S:123456789;T:WPA;P:123456;H:true;
		public override function isMatch(cont:String):Boolean {
			if (/^WIFI:/i.test(cont)) {
				return true;
			}
			return false;
		}
		
		public override function showForm(e:Event):void {
			var labelWidth:int = 50;
			var contWidth:int = 480 - labelWidth-10;
			
			addChild(createLabel('网络名称', 0, 10, labelWidth));
			network = createInput(labelWidth+10, 10, contWidth);
			addChild(network);
			
			addChild(createLabel('加密类型', 0, 40, labelWidth));
			passtype = new ComboBox();
			passtype.x = labelWidth+10;
			passtype.y = 40;
			passtype.addItem( { "label":"自动", "value":"" } );
			passtype.addItem( { "label":"WPA", "value":"WPA" } );
			passtype.addItem( { "label":"WEP", "value":"WEP" } );
			addChild(passtype);
			
			addChild(createLabel('密码', 0, 70, labelWidth));
			password = createInput(labelWidth+10, 70, contWidth);
			addChild(password);
		}
		
		public override function unserialize(cont:String):void {
			var str:String = cont.substr("WIFI:".length);
			var carr:Array = str.split(';');
			var line:String, mPos:int;
			for (var i:int = 0; i < carr.length; i++ ) {
				line = String(carr[i]).replace(/^\s*|\s*$/g, '');
				mPos = line.indexOf(':');
				if (mPos > 0) {
					switch(line.substr(0, mPos).toUpperCase()) {
					case "S":
						network.text = line.substr(mPos+1);
						break;
					case "T":
						// todo..
						passtype.selectedIndex = 1;
						break;
					case "P":
						password.text = line.substr(mPos+1);
						break;
					}
				}
			}
			
			
		}
		
		public override function serialize():String {
			if(passtype.selectedItem.value){
				return "WIFI:S:" + network.text + ";T:" + passtype.selectedItem.value + ";P:" + password.text +";";
			}else {
				return "WIFI:S:" + network.text + ";P:" + password.text +";";
			}
		}
		
	}

}