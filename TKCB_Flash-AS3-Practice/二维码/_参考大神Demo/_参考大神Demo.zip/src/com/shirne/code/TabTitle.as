package com.shirne.code 
{
	import flash.display.Sprite;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	import flash.text.TextFormatAlign;
	
	/**
	 * ...
	 * @author Shirne
	 */
	public class TabTitle extends Sprite 
	{
		public static var textFormat:TextFormat = null;
		public static var titleHeight:int = 30;
		public static var titleWidth:int = 80;
		
		private var text:TextField;
		private var _actived:Boolean = false;
		
		public function TabTitle(title:String) 
		{
			super();
			if (textFormat == null) {
				textFormat = new TextFormat("Microsoft YaHei", 14, 0, null, null, null, null, null, TextFormatAlign.CENTER);
			}
			text = new TextField();
			text.autoSize = TextFieldAutoSize.LEFT;
			text.defaultTextFormat = textFormat;
			text.text = title;
			text.selectable = false;
			text.mouseEnabled = false;
			text.y = 2;
			text.x = (titleWidth - text.width) * .5;
			addChild(text);
			active = false;
		}
		
		public function set active(bol:Boolean):void {
			_actived = bol;
			
			this.graphics.clear();
			if (bol) {
				this.graphics.beginFill(0x6666ff);
				this.graphics.drawRect(0, 0, titleWidth, titleHeight);
				this.graphics.endFill();
				text.textColor = 0xffffff;
			}else {
				this.graphics.beginFill(0,0);
				this.graphics.drawRect(0, 0, titleWidth, titleHeight);
				this.graphics.endFill();
				text.textColor = 0;
			}
		}
		
		public function get active():Boolean {
			return _actived;
		}
	}

}