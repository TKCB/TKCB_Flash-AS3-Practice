package com.shirne.code
{
	import com.google.zxing.common.BitMatrix;
	import com.google.zxing.EncodeHintType;
	import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
	import com.google.zxing.qrcode.encoder.Encoder;
	import com.google.zxing.Result;
	import fl.controls.Button;
	import fl.controls.ComboBox;
	import fl.controls.NumericStepper;
	import fl.controls.TextInput;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Loader;
	import flash.display.PNGEncoderOptions;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.events.ProgressEvent;
	import flash.events.SecurityErrorEvent;
	import flash.geom.Rectangle;
	import flash.net.FileFilter;
	import flash.net.FileReference;
	
	/**
	 * ...
	 * @author Shirne
	 */
	public class Setting extends Sprite
	{
		private var p:Object = new Object();
		
		private var _image:Sprite;
		private var _save:Button;
		private var _setting:Sprite;
		
		private var _forceColor:uint = 0xffffff;
		private var _bgColor:uint = 0;
		
		public static var imgSize:int = 200;
		
		public function Setting(onCreate:Function = null, onDecode:Function=null)
		{
			super();
			p.size = 200;
			p.charset = "UTF-8";
			
			_image = new Sprite();
			_image.graphics.beginFill(0, 0);
			_image.graphics.drawRect(0, 0, imgSize, imgSize);
			_image.graphics.endFill();
			_image.x = 50;
			addChild(_image);
			
			
			_setting = new Sprite();
			_setting.x = _image.width+150;
			
			var type:ComboBox = new ComboBox();
			type.addItem({"label": "低质量(L-7%)", "data": ErrorCorrectionLevel.L});
			type.addItem({"label": "中质量(M-15%)", "data": ErrorCorrectionLevel.M});
			type.addItem({"label": "高质量(Q-25%)", "data": ErrorCorrectionLevel.Q});
			type.addItem({"label": "最高质量(H-30%)", "data": ErrorCorrectionLevel.H});
			
			_setting.addChild(type);
			type.addEventListener(Event.CHANGE, function(e:Event):void
				{
					p[CodeForm.ERROR_CORRECTION] = type.selectedItem.data;
				});
				
			var charset:ComboBox = new ComboBox();
			charset.addItem({"label": "Default("+ Encoder.DEFAULT_BYTE_MODE_ENCODING.toLowerCase() +")", "data": Encoder.DEFAULT_BYTE_MODE_ENCODING});
			charset.addItem({"label": "utf-8", "data": "UTF-8"});
			//charset.addItem({"label": "gbk", "data": "GBK"});
			charset.addItem({"label": "Shift_JIS", "data": "Shift_JIS"});
			charset.addItem( { "label": "iso-8859-2", "data": "ISO8859_2" } );
			charset.addItem( { "label": "iso-8859-3", "data": "ISO8859_3" } );
			charset.addItem( { "label": "iso-8859-4", "data": "ISO8859_4" } );
			charset.addItem( { "label": "iso-8859-5", "data": "ISO8859_5" } );
			charset.addItem( { "label": "iso-8859-6", "data": "ISO8859_6" } );
			charset.addItem( { "label": "iso-8859-7", "data": "ISO8859_7" } );
			charset.addItem( { "label": "iso-8859-8", "data": "ISO8859_8" } );
			charset.addItem( { "label": "iso-8859-9", "data": "ISO8859_9" } );
			charset.addItem( { "label": "iso-8859-11", "data": "ISO8859_11" } );
			charset.addItem( { "label": "iso-8859-15", "data": "ISO8859_15" } );
			charset.y = type.height + 10;
			_setting.addChild(charset);
			charset.addEventListener(Event.CHANGE, function(e:Event):void
				{
					p["charset"] = charset.selectedItem.data;
				});
			charset.selectedIndex = 1;
			
			var size:NumericStepper = new NumericStepper();
			size.maximum = 1000;// imgSize;
			size.stepSize = 100;
			size.value = p.size;
			size.minimum = 50;
			size.y = charset.height + charset.y + 10;
			_setting.addChild(size);
			size.addEventListener(Event.CHANGE, function(e:Event):void
				{
					p['size'] = size.value;
				});
			
			var create:Button = new Button();
			create.label = "生成";
			create.y = size.height + size.y + 10;
			_setting.addChild(create);
			create.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void
				{
					if (onCreate==null)
						return;
					show( onCreate());
				});
			
			var reader:Button = new Button();
			reader.label = "解码";
			reader.y = create.height + create.y + 10;
			_setting.addChild(reader);
			reader.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void
				{
					var f:FileReference = new FileReference();
					f.addEventListener(SecurityErrorEvent.SECURITY_ERROR, emptyHandler);
					f.addEventListener(Event.SELECT, function(e:Event):void
						{
							f.load();
						});
					f.addEventListener(Event.COMPLETE, function(e:Event):void
						{
							var ldr:Loader = new Loader();
							ldr.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void
								{
									var bmp:Bitmap = ldr.content as Bitmap;
									Image = bmp;
									if (onDecode == null) return;
									decode(onDecode(bmp.bitmapData));
								});
							ldr.loadBytes(f.data);
						});
					f.browse([new FileFilter("Images", "*.jpg;*.png;*.gif")]);
				});
				
			
			_save = new Button();
			_save.label = "保存";
			_save.y = reader.y+reader.height+10;
			_save.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void
				{
					if (_image.numChildren < 1) return;
					var img:Bitmap = _image.getChildAt(0) as Bitmap;
					var bitmap:BitmapData = img.bitmapData;
					var file:FileReference = new FileReference();
					file.addEventListener(Event.CANCEL, emptyHandler);
					file.addEventListener(Event.OPEN, emptyHandler);
					file.addEventListener(Event.COMPLETE, emptyHandler);
					file.addEventListener(ProgressEvent.PROGRESS, emptyHandler);
					file.save(bitmap.encode(new Rectangle(0, 0, bitmap.width, bitmap.height), new PNGEncoderOptions()), "qrcode.png");
				});
			_setting.addChild(_save);
			
			addChild(_setting);
			
			this.graphics.beginFill(0,0);
			this.graphics.drawRect(0, 0, imgSize + 200, 200);
			this.graphics.endFill();
		}
		
		private function emptyHandler(e:Event = null):void {
			
		}
		
		public function decode(result:Result):void {
			
		}
		
		public function show(bytes:BitMatrix):void {
			var w:int = bytes.width, h:int = bytes.height;
			var bmp:BitmapData = new BitmapData(w, h);
			for (var i:int = 0; i < w; i++) {
				for (var j:int = 0; j < h;j++) {
					bmp.setPixel(i, j, bytes._get(i,j)?0:0xffffff);
				}
			}
			
			this.Image=new Bitmap(bmp);
		}
		
		public function set Image(bmp:Bitmap):void
		{
			while (_image.numChildren)
			{
				_image.removeChildAt(0);
			}
			
			if (bmp.height > imgSize) {
				bmp.scaleX = bmp.scaleY = imgSize / bmp.height;
			}
			
			bmp.y = (imgSize-bmp.height) * .5;
			bmp.x = (imgSize-bmp.width) * .5;
			
			_image.addChild(bmp);
		}
		
		public function get param():Object
		{
			return p;
		}
	
	}

}