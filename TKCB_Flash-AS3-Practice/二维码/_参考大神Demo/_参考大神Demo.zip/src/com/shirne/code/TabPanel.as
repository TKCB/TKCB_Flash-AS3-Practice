package com.shirne.code 
{
	import flash.display.DisplayObject;
	import flash.display.InteractiveObject;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	
	/**
	 * ...
	 * @author Shirne
	 */
	public class TabPanel extends Sprite 
	{
		private var _titles:Vector.<TabTitle> = new Vector.<TabTitle>();
		private var _contents:Vector.<CodeForm> = new Vector.<CodeForm>();
		
		private var _titleHeight:int = 30;
		private var _titleBox:Sprite;
		private var _contentBox:Sprite;
		
		private var activeIndex:int = 0;
		
		
		public function TabPanel() 
		{
			super();
			
			_titleBox = new Sprite();
			_titleBox.graphics.beginFill(0x6666ff);
			_titleBox.graphics.drawRect(0, _titleHeight, 500, 2);
			_titleBox.graphics.endFill();
			addChild(_titleBox);
			
			_contentBox = new Sprite();
			_contentBox.x = 10;
			_contentBox.y = _titleHeight + 2 + 5;
			_contentBox.graphics.beginFill(0, 0);
			_contentBox.graphics.drawRect(0,0,500, 300);
			_contentBox.graphics.endFill();
			addChild(_contentBox);
			
			addEventListener(Event.ADDED_TO_STAGE, loadActive);
		}
		
		public function loadActive(e:Event=null):void {
			active = 0;
		}
		
		public function getItem(index:int):CodeForm {
			if(index>=0 && index<_contents.length){
				return _contents[index];
			}
			return null;
		}
		
		public function get length():int {
			return _contents.length;
		}
		
		public function set active(index:int):void {
			if (index >= 0 && index < _titles.length) {
				_titles[activeIndex].active = false;
				_contents[activeIndex].visible = false;
				activeIndex = index;
				_titles[activeIndex].active=true;
				_contents[activeIndex].visible = true;
			}
		}
		public function get active():int {
			return activeIndex;
		}
		
		public function get activeItem():CodeForm {
			return _contents[activeIndex];
		}
		
		public function add(title:Sprite, content:CodeForm):void {
			_titles.push(title);
			_titleBox.addChild(title);
			if (_titles.length > 1) {
				title.x = _titles[_titles.length - 2].x + _titles[_titles.length - 2].width;
			}else {
				title.x = 10;
			}
			//_titleHeight = Math.max(_titleHeight, title.height);
			title.addEventListener(MouseEvent.CLICK, change);
			
			content.visible = false;
			_contents.push(content);
			_contentBox.addChild(content);
		}
		
		private function change(e:MouseEvent=null):void {
			var t:Sprite = e.target as Sprite;
			for (var i:int = 0; i < _titles.length; i++) {
				if (t == _titles[i]) {
					active = i;
					break;
				}
			}
		}
		
	}

}