package com.shirne.code 
{
	
	import fl.controls.Label;
	import fl.controls.TextArea;
	import fl.controls.TextInput;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFieldType;
	import flash.utils.ByteArray;
	
	/**
	 * ...
	 * @author Shirne
	 */
	public class CodeForm extends Sprite 
	{
		
		private var _width:int = 100;
		private var _height:int = 100;
		
		public static var ERROR_CORRECTION:String = "ERROR_CORRECTION";
		
		protected var _content:Object;
		
		private var form_content:TextArea;
		
		public function CodeForm() 
		{
			super();
			
			
			_content = new Object();
			_content.Text = "普通文本";
			
			addEventListener(Event.ADDED_TO_STAGE, showForm);
			
		}
		
		public function isMatch(cont:String):Boolean {
			return true;
		}
		
		public function showForm(e:Event):void {
			form_content = new TextArea();
			form_content.width = 480;
			form_content.height = 200;
			form_content.text = _content.Text;
			
			addChild(form_content);
		}
		
		public function setContent(cont:String):void {
			this._content.Text = cont;
			unserialize(cont);
		}
		
		public function getContent():String {
			_content.Text = serialize();
			return _content.Text;
		}
		
		public function unserialize(cont:String):void {
			form_content.text = cont;
		}
		
		public function serialize():String {
			
			return form_content.text;
		}
		
		
		
		protected function createInput(xPos:int=0,yPos:int=0,width:int=100):TextInput {
			var p:TextInput = new TextInput();
			p.x = xPos;
			p.y = yPos;
			p.width = width;
			return p;
		}
		
		protected function createTextArea(xPos:int=0,yPos:int=0,width:int=100):TextArea {
			var p:TextArea = new TextArea();
			p.x = xPos;
			p.y = yPos;
			p.width = width;
			return p;
		}
		
		protected function createLabel(text:String, xPos:int = 0, yPos:int = 0 ,width:int=60):Label {
			var l:Label = new Label();
			l.text = text;
			l.x = xPos;
			l.y = yPos;
			l.width = width;
			return l;
		}
	}

}