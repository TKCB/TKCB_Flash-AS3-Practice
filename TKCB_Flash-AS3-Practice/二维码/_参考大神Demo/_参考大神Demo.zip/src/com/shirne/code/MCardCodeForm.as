package com.shirne.code 
{
	import fl.controls.Label;
	import fl.controls.TextArea;
	import fl.controls.TextInput;
	import flash.events.Event;
	/**
	 * ...
	 * @author Shirne
	 */
	public class MCardCodeForm extends CodeForm 
	{
		private var fn:TextInput;
		private var mobile:TextInput;
		private var workphone:TextInput;
		private var fax:TextInput;
		private var email:TextInput;
		private var url:TextInput;
		private var org:TextInput;
		private var role:TextInput;
		private var title:TextInput;
		private var qq:TextInput;
		private var addr:TextInput;
		private var post:TextInput;
		private var note:TextArea;
		
		public function MCardCodeForm() 
		{
			super();
			_content.Text = "";
		}
		
		/**
		 * @param	e
		 */
		public override function showForm(e:Event):void {
			var line:int = 0;
			var lineHeight:int = 28;
			var labelWidth:int = 40;
			var sWidth:int = 480;
			
			var posLeft:int = labelWidth + 10;
			var posRight:int = labelWidth + 10 + sWidth * .5;
			var halftWidth:int = sWidth * .5 - labelWidth - 20;
			
			addChild(createLabel('姓名',0,line*lineHeight,labelWidth));
			fn = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(fn);
			
			addChild(createLabel('手机',sWidth*.5,line*lineHeight,labelWidth));
			mobile = createInput(posRight, line * lineHeight, halftWidth);
			addChild(mobile);
			
			line++;
			
			addChild(createLabel('邮箱',0,line*lineHeight,labelWidth));
			email = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(email);
			
			addChild(createLabel('主页',sWidth*.5,line*lineHeight,labelWidth));
			url = createInput(posRight, line * lineHeight, halftWidth);
			url.text = "http://";
			addChild(url);
			
			line++;
			
			addChild(createLabel('公司',0,line*lineHeight,labelWidth));
			org = createInput(posLeft, line * lineHeight, sWidth-labelWidth-20);
			addChild(org);
			
			line++;
			
			addChild(createLabel('职称',0,line*lineHeight,labelWidth));
			role = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(role);
			
			addChild(createLabel('QQ',sWidth*.5,line*lineHeight,labelWidth));
			qq = createInput(posRight, line * lineHeight, halftWidth);
			addChild(qq);
			/*addChild(createLabel('职位',sWidth*.5,line*lineHeight,labelWidth));
			title = createInput(posRight, line * lineHeight, halftWidth);
			addChild(title);*/
			
			line++;
			
			/*addChild(createLabel('电话',0,line*lineHeight,labelWidth));
			workphone = createInput(posLeft, line * lineHeight, halftWidth);
			addChild(workphone);
			
			addChild(createLabel('传真',sWidth*.5,line*lineHeight,labelWidth));
			fax = createInput(posRight, line * lineHeight, halftWidth);
			addChild(fax);
			
			line++;*/
			
			addChild(createLabel('地址',0,line*lineHeight,labelWidth));
			addr = createInput(posLeft, line * lineHeight, sWidth-labelWidth-20);
			addChild(addr);
			
			/*addChild(createLabel('邮编',sWidth*.5+100,line*lineHeight,labelWidth));
			post = createInput(posRight+100, line * lineHeight, halftWidth-100);
			addChild(post);*/
			
			line++;
			
			addChild(createLabel('备注',0,line*lineHeight,labelWidth));
			note = new TextArea();
			note.width = sWidth;
			note.height = 50;
			note.y = line * lineHeight;
			note.text = "备注";
			note.addEventListener(Event.CHANGE, function():void {
				_content.Text = serialize();
			});
			addChild(note);
		}
		
		public override function isMatch(cont:String):Boolean {
			if (cont.indexOf('MECARD:')==0) {
				return true;
			}
			return false;
		}
		
		public override function unserialize(val:String):void {
			var vCard:Object = new Object();
			var arrs:Array = val.substr('MECARD:'.length).split(";");
			var line:String;
			var mPos:int = -1;
			for (var i:int = 0; i < arrs.length; i++ ) {
				line = String(arrs[i]).replace(/^\s*|\s*$/g, '');
				mPos = line.indexOf(':');
				if (mPos > 0) {
					switch(line.substr(0,mPos).toUpperCase()) {
						case "N":
							vCard.fn = line.substr(mPos+1);
							break;
						case "TEL":
							vCard.mobile = line.substr(mPos+1);
							break;
						/*case "TEL":
							vCard.workphone = line.substr(mPos+1);
							break;*/
						case "EMAIL":
							vCard.email = line.substr(mPos+1);
							break;
						case "URL":
							vCard.url = line.substr(mPos+1);
							break;
						case "ORG":
							vCard.org = line.substr(mPos+1);
							break;
						case "ROLE":
							vCard.role = line.substr(mPos+1);
							break;
						case "QQ":
							vCard.qq = line.substr(mPos+1);
							break;
						case "TIL":
						case "TITLE":
							vCard.title = line.substr(mPos+1);
							break;
						case "ADR":
							var address:Array = line.substr(mPos+1).split(';');
							vCard.addr = address[0];
							vCard.post = address[1] || "";
							break;
						case "NOTE":
							vCard.note = line.substr(mPos+1);
							break;
					}
				}
			}
			
			fn.text = vCard.fn || "";
			mobile.text = vCard.mobile || "";
			//workphone.text = vCard.workphone || "";
			//fax.text = vCard.fax || "";
			email.text = vCard.email || "";
			url.text = vCard.url || "";
			org.text = vCard.org || "";
			role.text = vCard.role || "";
			//title.text = vCard.title || "";
			qq.text = vCard.qq || "";
			addr.text = vCard.addr || "";
			//post.text = vCard.post || "";
			note.text = vCard.note || "";
		}
		
		/**
		 * MECARD:N:魏晓江;ORG:捷联科技;TIL:项目经理;TEL:13631129077;EMAIL:shirne@126.com;ADR:中山市;
		 */
		public override function serialize():String {
			var str:Array=new Array();
			
			str.push("N:" + fn.text);
			if(mobile.text)str.push("TEL:" + mobile.text);
			//str.push("TEL:" + workphone.text);
			//str.push("TEL;WORK;FAX:" + fax.text);
			if(email.text)str.push("EMAIL:" + email.text);
			if(url.text)str.push("URL:" + url.text);
			if(org.text)str.push("ORG:" + org.text);
			if(role.text)str.push("ROLE:" + role.text);
			//if (title.text) str.push("TIL:" + title.text);
			if(qq.text)str.push("QQ:" + qq.text);
			if(addr.text)str.push("ADR:" + addr.text);// +" " + post.text);
			if(note.text)str.push("NOTE:" + note.text);
			
			return "MECARD:" + str.join(";");
		}
	}

}