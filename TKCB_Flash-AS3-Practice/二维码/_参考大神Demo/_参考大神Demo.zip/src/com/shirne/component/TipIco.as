package com.shirne.component 
{
	import flash.display.BitmapData;
	import flash.display.GradientType;
	import flash.display.Graphics;
	import flash.display.Sprite;
	import flash.events.TimerEvent;
	import flash.geom.Matrix;
	import flash.utils.Timer;
	
	/**
	 * 提示层图标
	 * @author Shirne http://www.shirne.com/
	 */
	public class TipIco extends Sprite 
	{
		//图标常量
		public static const LOADING:String = "loading";
		public static const OK:String = "ok";
		public static const ERROR:String = "error";
		public static const WARNING:String = "warning";
		
		[Embed(source = "/../lib/ok.png")]
		public static var okBMPClass:Class;
		public static var okBmp:BitmapData;
		
		[Embed(source = "/../lib/warning.png")]
		public static var warningBMPClass:Class;
		public static var warningBmp:BitmapData;
		
		[Embed(source = "/../lib/error.png")]
		public static var errorBMPClass:Class;
		public static var errorBmp:BitmapData;
		
		private var timer:Timer
		private var mtxRotat:Number = 0;
		private var size:Number = 10;
		
		public function TipIco() 
		{
			if (!okBmp) {
				okBmp = new okBMPClass().bitmapData;
				warningBmp = new warningBMPClass().bitmapData;
				errorBmp = new errorBMPClass().bitmapData;
			}
			
			timer = new Timer(100);
			timer.addEventListener(TimerEvent.TIMER, timing);
		}
		
		public function reset():void {
			timer.reset();
		}
		
		public function setStyle(style:String):void {
			timer.reset();
			if (this['ico_'+style]) {
				this['ico_'+style]();
			}
		}
		
		private function ico_loading():void {
			timer.start();
		}
		
		private function ico_ok():void {
			var mtx:Matrix = new Matrix();
			this.graphics.clear();
			this.graphics.beginBitmapFill(okBmp,new Matrix(1,0,0,1,-size,-size),false);
			this.graphics.drawRect(-size, -size, size * 2, size * 2);
			this.graphics.endFill();
		}
		
		private function ico_error():void {
			this.graphics.clear();
			this.graphics.beginBitmapFill(errorBmp,new Matrix(1,0,0,1,-size,-size),false);
			this.graphics.drawRect(-size, -size, size * 2, size * 2);
			this.graphics.endFill();
		}
		
		private function ico_warning():void {
			this.graphics.clear();
			this.graphics.beginBitmapFill(warningBmp,new Matrix(1,0,0,1,-size,-size),false);
			this.graphics.drawRect(-size, -size, size * 2, size * 2);
			this.graphics.endFill();
		}
		
		public function timing(e:TimerEvent):void {
			mtxRotat += 20;
			if (mtxRotat > 360) {
				mtxRotat = 0;
			}
			
			this.graphics.clear();
			drawCircle(this.graphics, size, [0xffffff, 0xffffff], [0, 1], [0, 255], 360, mtxRotat, size-2);
			
		}
		
		/**
		 * 绘制角度渐变的圆环或圆（innerDiameter为0是为圆），
		 * @param	gf 绘制的对象
		 * @param	externalDiameter 外径
		 * @param	colors 要在渐变中使用的 RGB 十六进制颜色值数组（例如，红色为 0xFF0000，蓝色为 0x0000FF，等等）。 
		 * @param	alphas colors 数组中对应颜色的 alpha 值数组；有效值为 0 到 1。 如果值小于 0，则默认值为 0。 如果值大于 1，则默认值为 1。
		 * @param	ratios 颜色分布比例的数组；有效值为 0 到 255。 该值定义 100% 采样的颜色所在位置的宽度百分比。
		 * @param	circleAngle 圆环角度
		 * @param	startAngle 渐变开始角度
		 * @param	innerDiameter 内径
		 * @return  void
		 * 
		 * AngleGradientFill.drawCircle(null, 50, [0xffffff, 0xcccccc], [1, 0], [0, 255], 270, 120, 0);
		 */
		public static function drawCircle(gf:Graphics, externalDiameter:Number, colors:Array, alphas:Array, ratios:Array, 
		                            circleAngle:uint = 360, startAngle:uint = 0, innerDiameter:Number = 0):void
		{
			
			if (!colors && !alphas && !ratios) {
				throw new Error("colors,alphas and ratios is null!");
				return null;
			}
			
			if (!externalDiameter) {
				throw new Error("externalDiameter is null!");
				return null;
			}
			
			circleAngle = circleAngle > 360?360:circleAngle;
			
			startAngle = startAngle > 360?startAngle % 360:startAngle;
			
			var len:uint;
			
			var i:int;
			
			var j:int;
			
			len = (
			      colors.length > alphas.length?
			            (alphas.length > ratios.length?ratios.length:alphas.length)
						:(colors.length > ratios.length?ratios.length:colors.length)
				  )-1;
			
			for (i = 0; i < len; i++ ) {
				var startRatio:Number = ratios[i];
			    var endRatio:Number = ratios[i + 1];
				var angle:Number = (endRatio - startRatio) / 255 * circleAngle;
				
				var stepA:Number = ((alphas[i + 1]<0?0:(alphas[i+1]>1?1:alphas[i+1])) - (alphas[i]<0?0:(alphas[i]>1?1:alphas[i])))/ angle;
				var stepR:Number = ((colors[i + 1] >> 16 & 0xff) - (colors[i] >> 16 & 0xff)) / angle;
				var stepG:Number = ((colors[i + 1] >> 8 & 0xff) - (colors[i] >> 8 & 0xff)) / angle;
				var stepB:Number = ((colors[i + 1] >> 0 & 0xff) - (colors[i] >> 0 & 0xff)) / angle;
				
				for (j = 0; j < angle; j++) {
					var alpha:Number = (alphas[i]<0?0:(alphas[i]>1?1:alphas[i])) + stepA * j;
					var red:uint = (colors[i] >> 16 & 0xff) + Math.round(stepR * j);
					var green:uint = (colors[i] >> 8 & 0xff) + Math.round(stepG * j);
					var blue:uint = (colors[i] >> 0 & 0xff) + Math.round(stepB * j);
					
					var color:uint = red << 16 | green << 8 | blue;
					
					gf.beginFill(color, alpha);
					gf.moveTo(innerDiameter * Math.cos((j + startAngle) / 180 * Math.PI), innerDiameter * Math.sin((j + startAngle)  / 180 * Math.PI));
					gf.lineTo(externalDiameter * Math.cos((j + startAngle) / 180 * Math.PI), externalDiameter * Math.sin((j + startAngle)  / 180 * Math.PI));
					gf.lineTo(externalDiameter * Math.cos((j + startAngle  + 1) / 180 * Math.PI), externalDiameter * Math.sin((j + startAngle  + 1) / 180 * Math.PI));
					gf.lineTo(innerDiameter * Math.cos((j + startAngle  + 1) / 180 * Math.PI), innerDiameter * Math.sin((j + startAngle  + 1) / 180 * Math.PI));
					gf.endFill();
				}
				
				startAngle += angle;
			}
			
		}
		
	}

}