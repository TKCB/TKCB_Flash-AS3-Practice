package com.google.zxing.client.result
{
	/*
 * Copyright 2008 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * @author jbreiden@google.com (Jeff Breidenbach)
 */
public final class ISBNParsedResult extends ParsedResult {

  private var isbn:String;

  public function ISBNParsedResult(isbn:String) {
    super(ParsedResultType.ISBN);
    this.isbn = isbn;
  }

  public function getISBN():String {
    return isbn;
  }

  public override function getDisplayResult():String {
    return isbn;
  }

}

}