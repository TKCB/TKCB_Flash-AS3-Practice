package 
{
	import com.google.zxing.BarcodeFormat;
	import com.google.zxing.Binarizer;
	import com.google.zxing.BinaryBitmap;
	import com.google.zxing.BufferedImageLuminanceSource;
	import com.google.zxing.common.BitMatrix;
	import com.google.zxing.common.flexdatatypes.HashTable;
	import com.google.zxing.common.GlobalHistogramBinarizer;
	import com.google.zxing.DecodeHintType;
	import com.google.zxing.EncodeHintType;
	import com.google.zxing.NotFoundException;
	import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
	import com.google.zxing.qrcode.QRCodeReader;
	import com.google.zxing.qrcode.QRCodeWriter;
	import com.google.zxing.Reader;
	import com.google.zxing.Result;
	import com.google.zxing.Writer;
	import com.shirne.code.*
	import com.shirne.component.FixedMenu;
	import com.shirne.component.Tip;
	import com.shirne.component.TipIco;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.DisplayObjectContainer;
	import flash.display.Sprite;
	import flash.display.StageScaleMode;
	import flash.events.Event;
	import flash.text.TextField;
	import flash.text.TextFormat;
	import flash.text.TextFormatAlign;
	import flash.utils.ByteArray;
	
	/**
	 * ...
	 * @author Shirne
	 */
	public class Main extends Sprite 
	{
		
		private var setting:Setting;
		private var contents:TabPanel;
		
		private var _param:HashTable;
		
		protected var writer:Writer;
		protected var reader:Reader;
		
		private var menu:FixedMenu;
		
		public function Main():void 
		{
			if (stage) init();
			else addEventListener(Event.ADDED_TO_STAGE, init);
		}
		
		private function init(e:Event = null):void 
		{
			removeEventListener(Event.ADDED_TO_STAGE, init);
			stage.scaleMode = StageScaleMode.NO_SCALE;
			
			menu = new FixedMenu(this, "临风小筑", "http://www.shirne.com");
			
			
			writer = new QRCodeWriter() as Writer;
			reader = new QRCodeReader() as Reader;
			
			setting = new Setting(onCreate, onDecode);
			addChild(setting);
			
			contents = new TabPanel();
			contents.y = Setting.imgSize+20;
			addChild(contents);
			
			
			setContent("文本", "");
			setContent("名片", "mcard");
			setContent("名片V3", "card");
			setContent("链接", "link");
			setContent("WIFI", "wifi");
			setContent("短信", "sms");
			
			contents.active = 0;
			
			Tip.init(this);
		}
		
		private function setContent(ttl:String,content:String):void {
			var formTitle:TabTitle = new TabTitle(ttl);
			
			var form:CodeForm
			switch(content) {
				case "card":
					form = new CardCodeForm();
					break;
				case "mcard":
					form = new MCardCodeForm();
					break;
				case "link":
					form = new LinkCodeForm();
					break;
				case "wifi":
					form = new WIFICodeForm();
					break;
				case "sms":
					form = new SMSCodeForm();
					break;
				default:
					form = new CodeForm();
			}
			contents.add(formTitle, form);
		}
		
		
		
		private function onCreate():BitMatrix {
			var param:Object = setting.param;
			
			_param = new HashTable(2);
			_param.Add(EncodeHintType.CHARACTER_SET, param.charset);
			_param.Add(EncodeHintType.ERROR_CORRECTION, param[CodeForm.ERROR_CORRECTION]);
			
			
			var str:String = contents.activeItem.getContent();
			
			var r:BitMatrix = writer.encode(str, BarcodeFormat.QR_CODE, param.size, param.size, _param) as BitMatrix;
			
			
			return r;
		}
		
		private function onDecode(bmp:BitmapData):Result {
			var param:Object = setting.param;
			_param = new HashTable(1);
			_param.Add(DecodeHintType.CHARACTER_SET, param.charset);
			Tip.show('正在解码');
			
			var binzer:Binarizer = new GlobalHistogramBinarizer(new BufferedImageLuminanceSource(bmp, 0, 0, bmp.width, bmp.height));
			var bmpb:BinaryBitmap = new BinaryBitmap(binzer);
			try{
				var result:Result = reader.decode(bmpb, _param);
			}catch (e:NotFoundException) {
				Tip.show('解码失败！',3,TipIco.ERROR);
				return null;
			}
			
			var matchIndex:int = 0;
			var text:String = result.getText();
			
			for (var i:int = 0; i < contents.length; i++ ) {
				if (contents.getItem(i).isMatch(text)) {
					matchIndex = i;
					contents.getItem(i).setContent(text);
				}
			}
			contents.active = matchIndex;
			Tip.close();
			
			return result;
		}
		
		private function utf16to8(str:String):String {  
			var out:String, i:int, len:int, c:uint;  
			out = "";  
			len = str.length;  
			for(i = 0; i < len; i++) {  
				c = str.charCodeAt(i);  
				if ((c >= 0x0001) && (c <= 0x007F)) {  
					out += str.charAt(i);  
				} else if (c > 0x07FF) {  
					out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));  
					out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));  
					out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));  
				} else {  
					out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));  
					out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));  
				}  
			}  
			return out;  
		}  
	}
	
}