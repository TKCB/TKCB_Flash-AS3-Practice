﻿package
{

	public class Hex62 {

		private static const HEX: Array = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

		private static const FLOAT: Array = [":", "(", ")", "[", "]", "{", "}", "<", ">"];

		private static const MOD: uint = HEX.length
		private static const MOD_16: uint = 16

		private static const LEN_62: uint = 7
		private static const HEXLEN_62: uint = 4
		private static const LEN_16: uint = 6
		private static const HEXLEN_16: uint = 5

		public function Hex62() {

		}

		/*10进制转换成62进制组
		 */
		public static function toHex62(num: String): String {
			var len: int = num.length;
			var float: int = num.indexOf(".");
			var bool: Boolean = false
			if (float >= 0 && float < len + 1) {
				bool = true;
				len -= len - float
			}

			var nums: Array = []
			var index: int = 0
			var min: int
			while (len - 1 >= index) {
				min = len - index - LEN_62
				min = min < 0 ? 0 : min
				nums.push(num.substring(min, len - index))
				index += LEN_62
			}

			if (bool) {
				nums[0] += num.substring(float, float + 2)
			}
			nums.reverse()
			var isfull: Boolean = false
			for (var s: String in nums) {
				isfull = s == "0" ? false : true
				nums[s] = toHexPart(nums[s], MOD, isfull)
			}
			return nums.join("");
		}

		/*10进制转换成16进制组
		 */
		public static function toHex16(num: String): String {
			var len: int = num.length;

			var nums: Array = []
			var index: int = 0
			var min: int
			while (len - 1 >= index) {
				min = len - index - LEN_16
				min = min < 0 ? 0 : min
				nums.push(num.substring(min, len - index))
				index += LEN_16
			}

			nums.reverse()

			var isfull: Boolean = false
			for (var s: String in nums) {
				isfull = s == "0" ? false : true
				nums[s] = toHexPart(nums[s], MOD_16, isfull)
			}
			return nums.join("");
		}

		/*16进制转换成62进制组
		 */
		public static function toHex62FromHex16(hex16: String): String {
			var len: int = hex16.length;

			var nums: Array = []
			var index: int = 0
			var min: int
			var temp: String
			while (len - 1 >= index) {
				min = len - index - LEN_62
				min = min < 0 ? 0 : min
				temp = hex16.substring(min, len - index)
				temp = Number("0x" + temp).toString()
				temp = Hex62.toHex62(temp)
				while (min != 0 && temp.length < HEXLEN_16) {
					temp = "0" + temp
				}
				nums.push(temp)
				index += LEN_62
			}

			nums.reverse()
			return nums.join("");
		}

		/*10进制转换成N进制
		 */
		private static function toHexPart(num: String, modNum: uint, isfull: Boolean): String {
			var len: int = num.length;
			var float: int = num.indexOf(".");
			var headNum: int = int(num)
			var floathex: String
			if (float >= 0 && float < len + 1) {
				floathex = FLOAT[int(num.substr(float + 1, 1)) - 1]
				headNum = int(num.substring(0, float))
			}

			var hexAry: Array = [0];
			var index: int = 0;
			var mod: int;

			while (true) {
				mod = headNum % modNum;
				hexAry[index] = mod;
				headNum -= mod;
				headNum /= modNum;
				if (headNum >= 1) {
					index++;
				} else {
					break
				}
			}

			hexAry.reverse()
			len = hexAry.length;
			num = "";
			for (index = 0; index < len; index++) {
				num += HEX[hexAry[index]];
			}
			if (isfull) {
				switch (modNum) {
					case MOD:
						len = HEXLEN_62
						break
					case MOD_16:
						len = HEXLEN_16
						break
				}
				while (num.length < len) {
					num = "0" + num
				}
			}
			if (floathex) {
				num += floathex
			}
			return num;
		}

		/*62进制组转换成10进制
		 */
		public static function toHex10(hex62: String): String {
			var len: int = hex62.length;
			var float: int = FLOAT.indexOf(hex62.substr(len - 1, 1))
			var floatNum: String = ""
			if (float >= 0) {
				floatNum = "." + (float + 1)
				len--
			}

			var nums: Array = []
			var index: int = 0
			var min: int
			while (len - 1 >= index) {
				min = len - index - HEXLEN_62
				min = min < 0 ? 0 : min
				nums.push(hex62.substring(min, len - index))
				index += HEXLEN_62
			}

			nums.reverse()
			var isfull: Boolean = false
			for (var s: String in nums) {
				isfull = s == "0" ? false : true
				nums[s] = toHex10Part(nums[s], MOD, isfull)
			}
			return nums.join("") + floatNum
		}

		/*16进制组转换成10进制
		 */
		public static function toHex10FromHex16(hex16: String): String {
			var len: int = hex16.length;

			var nums: Array = []
			var index: int = 0
			var min: int
			while (len - 1 >= index) {
				min = len - index - HEXLEN_16
				min = min < 0 ? 0 : min
				nums.push(hex16.substring(min, len - index))
				index += HEXLEN_16
			}

			nums.reverse()
			var isfull: Boolean = false
			for (var s: String in nums) {
				isfull = s == "0" ? false : true
				nums[s] = toHex10Part(nums[s], MOD_16, isfull)
			}

			return nums.join("")
		}

		/*62进制组转换成16进制
		 */
		public static function toHex16FromHex62(hex62: String): String {
			var len: int = hex62.length;

			var nums: Array = []
			var index: int = 0
			var min: int
			var temp: String
			while (len - 1 >= index) {
				min = len - index - HEXLEN_16
				min = min < 0 ? 0 : min
				temp = hex62.substring(min, len - index)
				temp = Number(Hex62.toHex10(temp)).toString(16)
				while (min != 0 && temp.length < LEN_62) {
					temp = "0" + temp
				}
				nums.push(temp)
				index += HEXLEN_16
			}

			nums.reverse()
			return nums.join("");
		}


		/*N进制转换成10进制
		 */
		/**
		 *
		 * @param hex
		 * @param modNum
		 * @param isfull
		 * @param hexLength
		 * @return
		 */
		private static function toHex10Part(hex: String, modNum: uint, isfull: Boolean = false): String {
			var len: int = hex.length

			var m: Number = 0
			var s: String
			for (var i: int = 0; i < len; i++) {
				for (s in HEX) {
					if (String(HEX[s]) == hex.substr(i, 1)) {
						m += pow(modNum, len - i - 1) * int(s)
						break
					}
				}
			}
			var num: String = m + ""
			if (isfull) {
				//                                if(hexLength<0){
				//                                        hexLength=modNum;
				//                                }
				switch (modNum) {
					case MOD:
						len = LEN_62
						break
					case MOD_16:
						len = LEN_16
						break
				}
				while (num.length < len) {
					num = "0" + num
				}
			}
			return num
		}

		private static function pow(x: int, y: int): Number {
			var v: Number = 1;
			for (var i: int = 0; i < y; i++) {
				v *= x;
			}
			return v;
		}

	}

}