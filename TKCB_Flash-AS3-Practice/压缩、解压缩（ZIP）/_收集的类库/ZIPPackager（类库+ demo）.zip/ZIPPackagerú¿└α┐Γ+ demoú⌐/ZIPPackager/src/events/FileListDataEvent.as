package events
{
	import flash.events.Event;
	
	public class FileListDataEvent extends Event
	{
		public static const FILE_LIST_DATA_ADD:String = "fileListDataAdded";
		public static const FILE_EXIST:String = "fileExist";
		
		/**
		 * FileReference or Array containing FileReference
		 */
		public var fileListData:Object;
		
		public function FileListDataEvent(type:String, bubbles:Boolean=false, cancelable:Boolean=false)
		{
			super(type, bubbles, cancelable);
		}
		
		
	}
}