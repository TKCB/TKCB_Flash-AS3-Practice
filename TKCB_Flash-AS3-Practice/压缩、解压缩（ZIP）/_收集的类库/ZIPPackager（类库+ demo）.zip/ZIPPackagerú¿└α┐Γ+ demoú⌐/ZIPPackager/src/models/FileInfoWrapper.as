package models
{
	import flash.utils.ByteArray;

	public class FileInfoWrapper
	{
		
		public var filename:String;
		public var modificationDate:Date;
		public var size:Number;
		
		public function FileInfoWrapper( filename:String )
		{
			this.filename = filename;
		}
	}
}