package flexUnitTests
{
	import flash.net.FileReference;

	public class MockFileReference extends FileReference
	{
		
		public function MockFileReference( name:String, size:Number )
		{
			this._name = name;
			this._size = size;
		}
		
		private var _name:String;

		override public function get name():String
		{
			return _name;
		}

		
		private var _size:Number;

		override public function get size():Number
		{
			return _size;
		}

	}
}