package flexUnitTests
{
	import mx.collections.ArrayCollection;
	
	import org.flexunit.asserts.assertEquals;
	import org.flexunit.asserts.assertFalse;
	import org.flexunit.asserts.assertTrue;
	import models.AppModel;

	public class FileListOperationTester
	{		
		private var model:AppModel;
		
		private var file1:MockFileReference = new MockFileReference( "13_55164_dbb8e798daf783d.jpg", 40200 ); 
		private var file2:MockFileReference = new MockFileReference( "abcd", 1234456 ); 
		private var file3:MockFileReference = new MockFileReference( "ersdfnf.img", 9731 ); 
		private var file0:MockFileReference = new MockFileReference( "abcd", 9731 );
		
		public function FileListOperationTester()
		{
			model = AppModel.getInstance();
		}
		
		[Before]
		public function setUp():void
		{
			model.packageFiles = new ArrayCollection();
			var ctrl:Controller = new Controller();
			var arr:Array = [ file1, file2, file3, file0 ];
			ctrl.addFiles(arr);
		}

		
		[After]
		public function tearDown():void
		{
		}
		
		
		[Test]
		public function testAddFiles():void
		{
			assertEquals( 4, model.packageFiles.length );
			assertTrue( model.packageFiles.contains(file0) );
			assertTrue( model.packageFiles.contains(file1) );
			assertTrue( model.packageFiles.contains(file2) );
			assertTrue( model.packageFiles.contains(file3) );
			
			var ctrl:Controller = new Controller();
			var file:MockFileReference = new MockFileReference( "abcd", 9731 );
			var arr:Array = new Array(file);
			ctrl.addFiles(arr);
			assertEquals( 4, model.packageFiles.length );
		}
		
		
		[Test]
		public function testClearFiles():void
		{
			var ctrl:Controller = new Controller();
			ctrl.clearFiles( Controller.PACKAGE_FILE_LIST );
			assertEquals( 0, model.packageFiles.length );
		}
		
		
		[Test]
		public function testRemoveFile():void
		{
			var ctrl:Controller = new Controller();
			assertTrue( ctrl.removeFile(file1) );
			assertEquals( 3, model.packageFiles.length );
			assertFalse( ctrl.removeFile( new MockFileReference( "fileNotExist.xxx", 1234 ) ) );
			assertEquals( 3, model.packageFiles.length );
			assertTrue( ctrl.removeFile(file2) );
			assertEquals( 2, model.packageFiles.length );
		}
		
	}
}