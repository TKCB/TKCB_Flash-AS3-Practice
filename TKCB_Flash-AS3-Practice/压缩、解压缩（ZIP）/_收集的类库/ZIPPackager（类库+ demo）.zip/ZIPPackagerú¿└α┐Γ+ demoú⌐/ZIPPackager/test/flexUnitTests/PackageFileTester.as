package flexUnitTests
{
	import bigt.iterable.isContains;
	
	import flash.events.ErrorEvent;
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.events.TimerEvent;
	import flash.globalization.DateTimeFormatter;
	import flash.globalization.LocaleID;
	import flash.net.URLLoader;
	import flash.net.URLLoaderDataFormat;
	import flash.net.URLRequest;
	import flash.utils.ByteArray;
	import flash.utils.Timer;
	
	import nochump.util.zip.ZipEntry;
	import nochump.util.zip.ZipFile;
	import nochump.util.zip.ZipOutput;
	
	import org.flexunit.asserts.assertEquals;
	import org.flexunit.asserts.assertTrue;
	import org.flexunit.async.Async;
	import models.FileInfoWrapper;
	import process.FilePackager;

	public class PackageFileTester
	{	
		private static const PATH_PREFIX:String = "assets/";
		private var filenames:Array = [ "AVStar1.xml", "Image00026.gif", "lesson.flv", "Object.jpg", "samplePdf.pdf", "swfaaa.swf", ];
		private var filesSize:Array = [];
		
		[Test(async)]
		public function testPackageSingleFile():void
		{
			var f:Function = Async.asyncHandler( this, onFileLoad, 500, filenames[0] );
			
			var loader:URLLoader = new URLLoader();
			loader.dataFormat = URLLoaderDataFormat.BINARY;
			var request:URLRequest = new URLRequest( PATH_PREFIX + filenames[0] );
			loader.addEventListener( Event.COMPLETE, f, false, 0, true );
			loader.load(request);
		}
		
		
		private function onFileLoad( e:Event, passThroughData:Object ):void
		{
			var loader:URLLoader = e.currentTarget as URLLoader;
			
			var packager:FilePackager = new FilePackager(); 
			var fi:FileInfoWrapper = new FileInfoWrapper( passThroughData as String );
			packager.putFile( fi, loader.data as ByteArray );
			packager.done();
			
			var zip:ZipFile = new ZipFile(packager.pack);
			assertEquals( 1, zip.entries.length );
			var entry:ZipEntry = zip.entries[0];
			assertEquals( filenames[0], entry.name );
			assertEquals( loader.bytesTotal, entry.size );
		}
		
		
		private var que:int = 0;
		private var packager:FilePackager = new FilePackager();
		[Test(async)]
		public function testPackageMultipleFiles():void
		{
			que = filenames.length;
			var loader:URLLoader;
			for (var i:int = 0; i < this.filenames.length; i++) 
			{
				loader = new URLLoader();
				loader.dataFormat = URLLoaderDataFormat.BINARY;
				loader.addEventListener( Event.COMPLETE, Async.asyncHandler( this, onFileLoad2, 500, i ), false, 0, true ); 
//				trace("loading: " + PATH_PREFIX + filenames[i] );
				loader.load( new URLRequest( PATH_PREFIX + filenames[i] ) );
			}
		}
		
		
		private function onFileLoad2( e:Event, passThroughData:Object ):void
		{
			var loader:URLLoader = e.currentTarget as URLLoader;
			var index:int = passThroughData as int;
//			trace( "============= load " + filenames[index] + " complete");
			filesSize[index] = loader.bytesTotal;
			var fi:FileInfoWrapper =  new FileInfoWrapper( filenames[index] as String );
			packager.putFile( fi, loader.data );
			if ( --que == 0 )
				asserts();
		}
		
		
		private function asserts():void
		{
			packager.done();
			
			var zip:ZipFile = new ZipFile( packager.pack );
			var entries:Array = zip.entries;
			assertEquals( 6, entries.length );
			
			var idx:int;
			for each ( var item:ZipEntry in entries ) 
			{
				idx = this.filenames.indexOf(item.name.toString());
				assertTrue( idx > -1 );
				assertEquals( this.filesSize[idx], item.size );
			}
			
			
		}
		
	}
}